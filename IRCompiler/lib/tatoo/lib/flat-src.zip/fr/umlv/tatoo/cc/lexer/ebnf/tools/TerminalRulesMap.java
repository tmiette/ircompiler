package fr.umlv.tatoo.cc.lexer.ebnf.tools;

import fr.umlv.tatoo.cc.lexer.ebnf.lexer.RuleEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.TerminalEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.VersionEnum;
import fr.umlv.tatoo.runtime.parser.Parser;
import fr.umlv.tatoo.runtime.tools.EnumParserLookaheadActivator;
import java.util.EnumMap;
import java.util.EnumSet;

/** 
 *  This class is generated - please do not edit it 
 */
public class TerminalRulesMap {
  public static EnumMap<TerminalEnum,EnumSet<RuleEnum>> getTerminalRulesMap() {
    EnumMap<TerminalEnum,EnumSet<RuleEnum>> map=new EnumMap<TerminalEnum,EnumSet<RuleEnum>>(TerminalEnum.class);
    map.put(TerminalEnum.rsqbracket,EnumSet.of(RuleEnum.rsqbracket));
    map.put(TerminalEnum.startsdecl,EnumSet.of(RuleEnum.startsdecl));
    map.put(TerminalEnum.plus,EnumSet.of(RuleEnum.plus));
    map.put(TerminalEnum.typesdecl,EnumSet.of(RuleEnum.typesdecl));
    map.put(TerminalEnum.prioritiesdecl,EnumSet.of(RuleEnum.prioritiesdecl));
    map.put(TerminalEnum.id,EnumSet.of(RuleEnum.id));
    map.put(TerminalEnum.branchesdecl,EnumSet.of(RuleEnum.branchesdecl));
    map.put(TerminalEnum.quote,EnumSet.of(RuleEnum.quote));
    map.put(TerminalEnum.lbracket,EnumSet.of(RuleEnum.lbracket));
    map.put(TerminalEnum.regexdoublequote,EnumSet.of(RuleEnum.regexdoublequote));
    map.put(TerminalEnum.eof,EnumSet.of(RuleEnum.eof));
    map.put(TerminalEnum.qmark,EnumSet.of(RuleEnum.qmark));
    map.put(TerminalEnum.number,EnumSet.of(RuleEnum.number));
    map.put(TerminalEnum.assign,EnumSet.of(RuleEnum.assign));
    map.put(TerminalEnum.qualifiedid,EnumSet.of(RuleEnum.qualifiedid));
    map.put(TerminalEnum.rbracket,EnumSet.of(RuleEnum.rbracket));
    map.put(TerminalEnum.slash,EnumSet.of(RuleEnum.slash));
    map.put(TerminalEnum.colon,EnumSet.of(RuleEnum.colon));
    map.put(TerminalEnum.productionsdecl,EnumSet.of(RuleEnum.productionsdecl));
    map.put(TerminalEnum.blanksdecl,EnumSet.of(RuleEnum.blanksdecl));
    map.put(TerminalEnum.regexquote,EnumSet.of(RuleEnum.regexquote));
    map.put(TerminalEnum.lsqbracket,EnumSet.of(RuleEnum.lsqbracket));
    map.put(TerminalEnum.errordecl,EnumSet.of(RuleEnum.errordecl));
    map.put(TerminalEnum.tokensdecl,EnumSet.of(RuleEnum.tokensdecl));
    map.put(TerminalEnum.doublequote,EnumSet.of(RuleEnum.doublequote));
    map.put(TerminalEnum.star,EnumSet.of(RuleEnum.star));
    map.put(TerminalEnum.lpar,EnumSet.of(RuleEnum.lpar));
    map.put(TerminalEnum.importsdecl,EnumSet.of(RuleEnum.importsdecl));
    map.put(TerminalEnum.dollar,EnumSet.of(RuleEnum.dollar));
    map.put(TerminalEnum.pipe,EnumSet.of(RuleEnum.pipe));
    map.put(TerminalEnum.directivesdecl,EnumSet.of(RuleEnum.directivesdecl));
    map.put(TerminalEnum.versionsdecl,EnumSet.of(RuleEnum.versionsdecl));
    map.put(TerminalEnum.rpar,EnumSet.of(RuleEnum.rpar));
    map.put(TerminalEnum.assoc,EnumSet.of(RuleEnum.assoc));
    map.put(TerminalEnum.semicolon,EnumSet.of(RuleEnum.semicolon));
    map.put(TerminalEnum.quoted_name,EnumSet.of(RuleEnum.quoted_name));
    return map;
  }

  public static EnumSet<RuleEnum> getUnconditionalRules() {
    return  EnumSet.of(RuleEnum.space);
  }

  public static EnumParserLookaheadActivator<RuleEnum,TerminalEnum,VersionEnum> getActivator(Parser<TerminalEnum,?,?,VersionEnum> parser) {
    return new EnumParserLookaheadActivator<RuleEnum,TerminalEnum,VersionEnum>(
      parser,getTerminalRulesMap(),RuleEnum.class,getUnconditionalRules());
  }
}
