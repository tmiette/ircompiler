package fr.umlv.tatoo.cc.lexer.regex.pattern.tools;

import fr.umlv.tatoo.cc.lexer.regex.pattern.lexer.RuleEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.TerminalEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.VersionEnum;
import fr.umlv.tatoo.runtime.parser.Parser;
import fr.umlv.tatoo.runtime.tools.EnumParserLookaheadActivator;
import java.util.EnumMap;
import java.util.EnumSet;

/** 
 *  This class is generated - please do not edit it 
 */
public class TerminalRulesMap {
  public static EnumMap<TerminalEnum,EnumSet<RuleEnum>> getTerminalRulesMap() {
    EnumMap<TerminalEnum,EnumSet<RuleEnum>> map=new EnumMap<TerminalEnum,EnumSet<RuleEnum>>(TerminalEnum.class);
    map.put(TerminalEnum.plus,EnumSet.of(RuleEnum.plus));
    map.put(TerminalEnum.lpar,EnumSet.of(RuleEnum.lpar));
    map.put(TerminalEnum.intervalLetter,EnumSet.of(RuleEnum.intervalEscapedChar, RuleEnum.intervalChar));
    map.put(TerminalEnum.hat,EnumSet.of(RuleEnum.hat));
    map.put(TerminalEnum.rbrak,EnumSet.of(RuleEnum.rbrak));
    map.put(TerminalEnum.quote,EnumSet.of(RuleEnum.quote));
    map.put(TerminalEnum.lbrac,EnumSet.of(RuleEnum.lbrac));
    map.put(TerminalEnum.comma,EnumSet.of(RuleEnum.comma));
    map.put(TerminalEnum.rpar,EnumSet.of(RuleEnum.rpar));
    map.put(TerminalEnum.minus,EnumSet.of(RuleEnum.minus));
    map.put(TerminalEnum.slash,EnumSet.of(RuleEnum.slash));
    map.put(TerminalEnum.dot,EnumSet.of(RuleEnum.dot));
    map.put(TerminalEnum.integer,EnumSet.of(RuleEnum.integer));
    map.put(TerminalEnum.star,EnumSet.of(RuleEnum.star));
    map.put(TerminalEnum.dollar,EnumSet.of(RuleEnum.dollar));
    map.put(TerminalEnum.specialLetter,EnumSet.of(RuleEnum.backspace, RuleEnum.tab, RuleEnum.cr, RuleEnum.formfeed, RuleEnum.unicodeChar, RuleEnum.eoln));
    map.put(TerminalEnum.lbrak,EnumSet.of(RuleEnum.lbrak));
    map.put(TerminalEnum.stringLetter,EnumSet.of(RuleEnum.stringChar, RuleEnum.stringEscapedChar));
    map.put(TerminalEnum.rbrac,EnumSet.of(RuleEnum.rbrac));
    map.put(TerminalEnum.name,EnumSet.of(RuleEnum.macro));
    map.put(TerminalEnum.question,EnumSet.of(RuleEnum.question));
    map.put(TerminalEnum.pipe,EnumSet.of(RuleEnum.pipe));
    map.put(TerminalEnum.normalLetter,EnumSet.of(RuleEnum.escapedChar, RuleEnum.normalChar));
    return map;
  }

  public static EnumSet<RuleEnum> getUnconditionalRules() {
    return   EnumSet.noneOf(RuleEnum.class);
  }

  public static EnumParserLookaheadActivator<RuleEnum,TerminalEnum,VersionEnum> getActivator(Parser<TerminalEnum,?,?,VersionEnum> parser) {
    return new EnumParserLookaheadActivator<RuleEnum,TerminalEnum,VersionEnum>(
      parser,getTerminalRulesMap(),RuleEnum.class,getUnconditionalRules());
  }
}
