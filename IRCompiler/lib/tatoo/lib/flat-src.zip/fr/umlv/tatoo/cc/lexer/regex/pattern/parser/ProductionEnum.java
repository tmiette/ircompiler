package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

/** 
 *  This class is generated - please do not edit it 
 */
public enum ProductionEnum {
  initial, macro, mainRegex, followEmpty, followDollar, followRegex, hatEmpty, hatPresent, regexMacro, regexAny, regexLetter, normalLetter, normalSpecialLetter, regexString, string, specialOrStringLetter, stringSpecialLetter, stringLetter, regexInterval, regexIntervalNegate, interval, intervals, intervalSet, intervalSingleton, intervalSpecialLetter, intervalLetter, regexStar, regexPlus, regexOptional, regexRange, regexAtLeast, regexTimes, regexPar, regexCat, regexOr;}