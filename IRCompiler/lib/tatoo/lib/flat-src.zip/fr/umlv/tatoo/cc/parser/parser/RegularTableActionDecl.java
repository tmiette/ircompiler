package fr.umlv.tatoo.cc.parser.parser;

public interface RegularTableActionDecl extends ActionDecl{
  // marker interface
}
