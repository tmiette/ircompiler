package fr.umlv.tatoo.cc.lexer.regex.pattern.tools;

import fr.umlv.tatoo.cc.lexer.charset.CharacterInterval;
import fr.umlv.tatoo.cc.lexer.regex.Regex;
import fr.umlv.tatoo.cc.lexer.regex.RegexIntervalTable;
import java.util.ArrayList;
import fr.umlv.tatoo.cc.lexer.regex.pattern.lexer.RuleEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.TerminalEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.tools.TerminalEvaluator;
import fr.umlv.tatoo.cc.lexer.regex.pattern.tools.GrammarEvaluator;

import fr.umlv.tatoo.runtime.buffer.LexerBuffer;
import fr.umlv.tatoo.runtime.lexer.LexerListener;
import fr.umlv.tatoo.runtime.parser.SimpleParser;
import fr.umlv.tatoo.runtime.parser.SmartStepReturn;
import fr.umlv.tatoo.runtime.tools.DataViewer;
import fr.umlv.tatoo.runtime.tools.GenericStack;
import fr.umlv.tatoo.runtime.tools.AbstractToolsProcessor;

/**  This class is called by the parser when
 *   <ol>
 *    <li>a terminal is shifted
 *    <li>a non terminal is reduced
 *    <li>a non terminal is accepted
 *   </ol>
 *   In that case, depending on the information of the .xtls, terminal and non-terminal
 *   values are pushed or pop from a semantic stack.
 *   
 *   Furthermore, in case of error recovery, values of the stack can be pop out
 *   depending if the last recognized element is a terminal or a non-terminal.
 * 
 *  This class is generated - please do not edit it 
 */
public class ToolsProcessor<B extends LexerBuffer,D>
  extends AbstractToolsProcessor<B,RuleEnum,TerminalEnum,NonTerminalEnum,ProductionEnum> {
 
  B buffer;
    
                          RuleEnum rule;

  private final GrammarEvaluator grammarEvaluator;
  private final TerminalEvaluator<? super D> terminalEvaluator;
  private final DataViewer<? super B,? extends D> dataViewer;
  private final GenericStack stack;

  /** Creates a tools processor.
      This constructor allows to share the same stack between more
      than one parser processor.
      @param terminalEvaluator the terminal evaluator.
      @param grammarEvaluator the grammar evaluator.
      @param stack the stack used by the processor
   */
  private ToolsProcessor(TerminalEvaluator<? super D> terminalEvaluator, GrammarEvaluator grammarEvaluator, DataViewer<? super B,? extends D> dataViewer, GenericStack stack) {
    this.terminalEvaluator=terminalEvaluator;
    this.grammarEvaluator=grammarEvaluator;
    this.dataViewer=dataViewer;
    this.stack=stack;
  }
  
  public static <B extends LexerBuffer,D> AbstractToolsProcessor<B,RuleEnum,TerminalEnum,NonTerminalEnum,ProductionEnum>
    createToolsProcessor(TerminalEvaluator<? super D> terminalEvaluator, GrammarEvaluator grammarEvaluator, DataViewer<? super B,? extends D> dataViewer, GenericStack stack) {
    
    return new ToolsProcessor<B,D>(terminalEvaluator,grammarEvaluator,dataViewer,stack);
  }
  
  /** Creates a lexer listener that forwards recognized rule to the parser.
   * @param parser a parser
   * @return a lexer listener.
   */
  @Override
  public LexerListener<RuleEnum,B> createLexerListener(SimpleParser<? super TerminalEnum> parser) {
    return new LexerAdapter(parser);
  }
  
  protected class LexerAdapter implements LexerListener<RuleEnum,B> {
    private final SimpleParser<? super TerminalEnum> parser;
    
    protected LexerAdapter(SimpleParser<? super TerminalEnum> parser) {
      this.parser=parser;
    }
    
    
    /**
     * {@inheritDoc}
     */
    public final void ruleVerified(RuleEnum rule, int lastTokenLength,B buffer)  {   
    ToolsProcessor.this.buffer=buffer; 
    try {
      switch(rule) {
        case dot:
                 if (parser.smartStep(TerminalEnum.dot)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case hat:
                 if (parser.smartStep(TerminalEnum.hat)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case quote:
                 if (parser.smartStep(TerminalEnum.quote)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case comma:
                 if (parser.smartStep(TerminalEnum.comma)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case star:
                 if (parser.smartStep(TerminalEnum.star)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case plus:
                 if (parser.smartStep(TerminalEnum.plus)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case minus:
                 if (parser.smartStep(TerminalEnum.minus)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case slash:
                 if (parser.smartStep(TerminalEnum.slash)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case dollar:
                 if (parser.smartStep(TerminalEnum.dollar)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case question:
                 if (parser.smartStep(TerminalEnum.question)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case lbrak:
                 if (parser.smartStep(TerminalEnum.lbrak)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case rbrak:
                 if (parser.smartStep(TerminalEnum.rbrak)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case lbrac:
                 if (parser.smartStep(TerminalEnum.lbrac)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case rbrac:
                 if (parser.smartStep(TerminalEnum.rbrac)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case lpar:
                 if (parser.smartStep(TerminalEnum.lpar)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case rpar:
                 if (parser.smartStep(TerminalEnum.rpar)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case pipe:
                 if (parser.smartStep(TerminalEnum.pipe)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case eoln:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.specialLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case cr:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.specialLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case formfeed:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.specialLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case tab:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.specialLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case backspace:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.specialLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case unicodeChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.specialLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case escapedChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.normalLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case stringEscapedChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.stringLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case intervalEscapedChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.intervalLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case normalChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.normalLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case stringChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.stringLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case intervalChar:
                 ToolsProcessor.this.rule = rule;
             if (parser.smartStep(TerminalEnum.intervalLetter)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case integer:
                 if (parser.smartStep(TerminalEnum.integer)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case macro:
                 if (parser.smartStep(TerminalEnum.name)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        }
        throw new AssertionError("unknown rule "+rule);
      }
      finally {
        ToolsProcessor.this.buffer = null;
      }
    }
  }

  public void shift(TerminalEnum terminal) {
     D data;
     switch(terminal) {
      case plus: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case star: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case question: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case minus: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case slash: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case comma: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case hat: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case dollar: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case pipe: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case integer: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             int integer= terminalEvaluator.integer(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_int(integer);
         return;
      }
      case lbrac: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case rbrac: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case lpar: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case rpar: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case lbrak: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case rbrak: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case quote: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case dot: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case name: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             String name= terminalEvaluator.macro(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(name);
         return;
      }
      case specialLetter: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
               char specialLetter;
           switch(ToolsProcessor.this.rule) {
             case backspace:
           specialLetter= terminalEvaluator.backspace(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case tab:
           specialLetter= terminalEvaluator.tab(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case cr:
           specialLetter= terminalEvaluator.cr(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case formfeed:
           specialLetter= terminalEvaluator.formfeed(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case unicodeChar:
           specialLetter= terminalEvaluator.unicodeChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case eoln:
           specialLetter= terminalEvaluator.eoln(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             default:
             throw new AssertionError("Unknown rule " +ToolsProcessor.this.rule);
        }
            stack.push_char(specialLetter);
         return;
      }
      case normalLetter: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
               char normalLetter;
           switch(ToolsProcessor.this.rule) {
             case escapedChar:
           normalLetter= terminalEvaluator.escapedChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case normalChar:
           normalLetter= terminalEvaluator.normalChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             default:
             throw new AssertionError("Unknown rule " +ToolsProcessor.this.rule);
        }
            stack.push_char(normalLetter);
         return;
      }
      case stringLetter: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
               char stringLetter;
           switch(ToolsProcessor.this.rule) {
             case stringChar:
           stringLetter= terminalEvaluator.stringChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case stringEscapedChar:
           stringLetter= terminalEvaluator.stringEscapedChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             default:
             throw new AssertionError("Unknown rule " +ToolsProcessor.this.rule);
        }
            stack.push_char(stringLetter);
         return;
      }
      case intervalLetter: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
               char intervalLetter;
           switch(ToolsProcessor.this.rule) {
             case intervalEscapedChar:
           intervalLetter= terminalEvaluator.intervalEscapedChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             case intervalChar:
           intervalLetter= terminalEvaluator.intervalChar(data);
                    ToolsProcessor.this.buffer.discard();
                break;
             default:
             throw new AssertionError("Unknown rule " +ToolsProcessor.this.rule);
        }
            stack.push_char(intervalLetter);
         return;
      }
      case __eof__: {
            return;
      }
    }
    throw new AssertionError("unknown terminal "+terminal);
  }

  @SuppressWarnings("unchecked")
  public void reduce(ProductionEnum production) {
    switch(production) {
      case initial: {
// ast false
// starType NO_STAR

          RegexIntervalTable follow=(RegexIntervalTable) stack.pop_Object();

          RegexIntervalTable main=(RegexIntervalTable) stack.pop_Object();

          boolean hatOpt= stack.pop_boolean();
            grammarEvaluator.initial(hatOpt, main, follow);
            return;
      }
      case macro: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
            grammarEvaluator.macro(regex);
            return;
      }
      case mainRegex: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.mainRegex(regex));
          return;
      }
      case followEmpty: {
// ast false
// starType NO_STAR
          stack.push_Object(grammarEvaluator.followEmpty());
          return;
      }
      case followDollar: {
// ast false
// starType NO_STAR
          stack.push_Object(grammarEvaluator.followDollar());
          return;
      }
      case followRegex: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.followRegex(regex));
          return;
      }
      case hatEmpty: {
// ast false
// starType NO_STAR
          stack.push_boolean(grammarEvaluator.hatEmpty());
          return;
      }
      case hatPresent: {
// ast false
// starType NO_STAR
          stack.push_boolean(grammarEvaluator.hatPresent());
          return;
      }
      case regexMacro: {
// ast false
// starType NO_STAR

          String name=(String) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexMacro(name));
          return;
      }
      case regexAny: {
// ast false
// starType NO_STAR
          stack.push_Object(grammarEvaluator.regexAny());
          return;
      }
      case regexLetter: {
// ast false
// starType NO_STAR

          char specialOrNormalLetter= stack.pop_char();
          stack.push_Object(grammarEvaluator.regexLetter(specialOrNormalLetter));
          return;
      }
      case normalLetter: {
// ast false
// starType NO_STAR

          char normalLetter= stack.pop_char();
          stack.push_char(grammarEvaluator.normalLetter(normalLetter));
          return;
      }
      case normalSpecialLetter: {
// ast false
// starType NO_STAR

          char specialLetter= stack.pop_char();
          stack.push_char(grammarEvaluator.normalSpecialLetter(specialLetter));
          return;
      }
      case regexString: {
// ast false
// starType NO_STAR

          Regex string=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexString(string));
          return;
      }
      case string: {
// ast false
// starType NO_STAR

          Regex specialOrStringLetter=(Regex) stack.pop_Object();

          Regex string=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.string(string, specialOrStringLetter));
          return;
      }
      case specialOrStringLetter: {
// ast false
// starType NO_STAR

          Regex specialOrStringLetter=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.specialOrStringLetter(specialOrStringLetter));
          return;
      }
      case stringSpecialLetter: {
// ast false
// starType NO_STAR

          char specialLetter= stack.pop_char();
          stack.push_Object(grammarEvaluator.stringSpecialLetter(specialLetter));
          return;
      }
      case stringLetter: {
// ast false
// starType NO_STAR

          char stringLetter= stack.pop_char();
          stack.push_Object(grammarEvaluator.stringLetter(stringLetter));
          return;
      }
      case regexInterval: {
// ast false
// starType NO_STAR

          ArrayList<CharacterInterval> intervals=(ArrayList<CharacterInterval>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexInterval(intervals));
          return;
      }
      case regexIntervalNegate: {
// ast false
// starType NO_STAR

          ArrayList<CharacterInterval> intervals=(ArrayList<CharacterInterval>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexIntervalNegate(intervals));
          return;
      }
      case interval: {
// ast false
// starType NO_STAR

          CharacterInterval interval=(CharacterInterval) stack.pop_Object();
          stack.push_Object(grammarEvaluator.interval(interval));
          return;
      }
      case intervals: {
// ast false
// starType NO_STAR

          CharacterInterval interval=(CharacterInterval) stack.pop_Object();

          ArrayList<CharacterInterval> intervals=(ArrayList<CharacterInterval>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.intervals(intervals, interval));
          return;
      }
      case intervalSet: {
// ast false
// starType NO_STAR

          char specialOrIntervalLetter2= stack.pop_char();

          char specialOrIntervalLetter= stack.pop_char();
          stack.push_Object(grammarEvaluator.intervalSet(specialOrIntervalLetter, specialOrIntervalLetter2));
          return;
      }
      case intervalSingleton: {
// ast false
// starType NO_STAR

          char specialOrIntervalLetter= stack.pop_char();
          stack.push_Object(grammarEvaluator.intervalSingleton(specialOrIntervalLetter));
          return;
      }
      case intervalSpecialLetter: {
// ast false
// starType NO_STAR

          char specialLetter= stack.pop_char();
          stack.push_char(grammarEvaluator.intervalSpecialLetter(specialLetter));
          return;
      }
      case intervalLetter: {
// ast false
// starType NO_STAR

          char intervalLetter= stack.pop_char();
          stack.push_char(grammarEvaluator.intervalLetter(intervalLetter));
          return;
      }
      case regexStar: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexStar(regex));
          return;
      }
      case regexPlus: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexPlus(regex));
          return;
      }
      case regexOptional: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexOptional(regex));
          return;
      }
      case regexRange: {
// ast false
// starType NO_STAR

          int integer2= stack.pop_int();

          int integer= stack.pop_int();

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexRange(regex, integer, integer2));
          return;
      }
      case regexAtLeast: {
// ast false
// starType NO_STAR

          int integer= stack.pop_int();

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexAtLeast(regex, integer));
          return;
      }
      case regexTimes: {
// ast false
// starType NO_STAR

          int integer= stack.pop_int();

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexTimes(regex, integer));
          return;
      }
      case regexPar: {
// ast false
// starType NO_STAR

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexPar(regex));
          return;
      }
      case regexCat: {
// ast false
// starType NO_STAR

          Regex regex2=(Regex) stack.pop_Object();

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexCat(regex, regex2));
          return;
      }
      case regexOr: {
// ast false
// starType NO_STAR

          Regex regex2=(Regex) stack.pop_Object();

          Regex regex=(Regex) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regexOr(regex, regex2));
          return;
      }
    }
    throw new AssertionError("unknown production "+production);
  }

  @SuppressWarnings("unchecked")
  public void accept(NonTerminalEnum nonterminal) {
    switch(nonterminal) {
      case pattern:
        return;
      case macro:
        return;
      default:
    }
    throw new AssertionError("unknown start nonterminal "+nonterminal);
  }

  public void popTerminalOnError(TerminalEnum terminal) {
    switch(terminal) {
      case plus:
        return;
      case star:
        return;
      case question:
        return;
      case minus:
        return;
      case slash:
        return;
      case comma:
        return;
      case hat:
        return;
      case dollar:
        return;
      case pipe:
        return;
      case integer:
        stack.pop_int();
        return;
      case lbrac:
        return;
      case rbrac:
        return;
      case lpar:
        return;
      case rpar:
        return;
      case lbrak:
        return;
      case rbrak:
        return;
      case quote:
        return;
      case dot:
        return;
      case name:
        stack.pop_Object();
        return;
      case specialLetter:
        stack.pop_char();
        return;
      case normalLetter:
        stack.pop_char();
        return;
      case stringLetter:
        stack.pop_char();
        return;
      case intervalLetter:
        stack.pop_char();
        return;
      case __eof__:
        return;
    }
    throw new AssertionError("unknown terminal "+terminal);
  }

  public void popNonTerminalOnError(NonTerminalEnum nonterminal) {
    switch(nonterminal) {
      case pattern:
        return;
      case macro:
        return;
      case hatOpt:
        stack.pop_boolean();
        return;
      case main:
        stack.pop_Object();
        return;
      case follow:
        stack.pop_Object();
        return;
      case regex:
        stack.pop_Object();
        return;
      case specialOrNormalLetter:
        stack.pop_char();
        return;
      case string:
        stack.pop_Object();
        return;
      case specialOrStringLetter:
        stack.pop_Object();
        return;
      case intervals:
        stack.pop_Object();
        return;
      case interval:
        stack.pop_Object();
        return;
      case specialOrIntervalLetter:
        stack.pop_char();
        return;
    }
    throw new AssertionError("unknown nonterminal "+nonterminal);
  }
}
