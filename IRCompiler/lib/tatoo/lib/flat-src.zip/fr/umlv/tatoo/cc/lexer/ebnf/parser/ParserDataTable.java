package fr.umlv.tatoo.cc.lexer.ebnf.parser;

import fr.umlv.tatoo.cc.lexer.ebnf.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.TerminalEnum;
import fr.umlv.tatoo.runtime.parser.AcceptAction;
import fr.umlv.tatoo.runtime.parser.Action;
import fr.umlv.tatoo.runtime.parser.BranchAction;
import fr.umlv.tatoo.runtime.parser.ErrorAction;
import fr.umlv.tatoo.runtime.parser.ExitAction;
import fr.umlv.tatoo.runtime.parser.ParserTable;
import fr.umlv.tatoo.runtime.parser.ReduceAction;
import fr.umlv.tatoo.runtime.parser.ShiftAction;
import fr.umlv.tatoo.runtime.parser.StateMetadata;
import java.util.EnumMap;

/** 
 *  This class is generated - please do not edit it 
 */
public class ParserDataTable {
  @SuppressWarnings("unchecked")
  private ParserDataTable() {
    accept = AcceptAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    exit = ExitAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    initproduction_id_optional19Gotoes();
    initstart_non_terminals_optional8Gotoes();
    initvarGotoes();
    initblank_lhsGotoes();
    initpriority_listGotoes();
    initterminal_or_prod_priority_optional18Gotoes();
    initdirectives_lhsGotoes();
    initproduction_lhsGotoes();
    initstart_non_terminalsGotoes();
    initbranch_lhsGotoes();
    initstartidGotoes();
    initregexGotoes();
    inittoken_lhsGotoes();
    initerror_lhs_optional5Gotoes();
    initprodsGotoes();
    inittokens_listGotoes();
    initregex_terminal_declGotoes();
    initqmark_optional22Gotoes();
    initseparatorGotoes();
    initpriorityGotoes();
    initseparator_optional23Gotoes();
    initaliasGotoes();
    initvariableGotoes();
    inittype_optional11Gotoes();
    initlexemGotoes();
    initproduction_idGotoes();
    initprodGotoes();
    initseparator_optional26Gotoes();
    inittype_optional14Gotoes();
    initalias_optional10Gotoes();
    initimport_listGotoes();
    initpriorities_lhs_optional2Gotoes();
    initerror_lhsGotoes();
    inittypes_lhsGotoes();
    initproduction_version_optional20Gotoes();
    initversionGotoes();
    initseparator_optional24Gotoes();
    initparent_versionGotoes();
    initpriorities_lhsGotoes();
    initbanches_listGotoes();
    initdeclGotoes();
    initvartypedefGotoes();
    initbranch_lhs_optional4Gotoes();
    initvartypedef_listGotoes();
    initimports_lhs_optional1Gotoes();
    initversions_optional6Gotoes();
    initstarts_listGotoes();
    initvarlistGotoes();
    initvargroupGotoes();
    initblanks_listGotoes();
    initterminal_or_prod_priority_optional15Gotoes();
    initseparator_optional25Gotoes();
    initterminal_or_prod_priority_optional16Gotoes();
    initregex_terminal_decl_optional12Gotoes();
    initbranch_lexemGotoes();
    inittypes_lhs_optional7Gotoes();
    initproduction_versionGotoes();
    initterminal_or_prod_priorityGotoes();
    initdirective_listGotoes();
    initterminal_or_prod_priority_optional13Gotoes();
    initdeclsGotoes();
    initversionsGotoes();
    initstartGotoes();
    initdirectives_lhs_optional0Gotoes();
    inittype_optional17Gotoes();
    initimport_Gotoes();
    initversion_listGotoes();
    initblank_lhs_optional3Gotoes();
    initqmark_optional21Gotoes();
    initimports_lhsGotoes();
    initblank_lexemGotoes();
    inittypeGotoes();
    initdirectiveGotoes();
    initparent_version_optional9Gotoes();
    reducevar_nonterminal_star = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_nonterminal_star,3,varGotoes);
    reduceblank_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_def,3,blank_lhsGotoes);
    reducevar_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_terminal,4,varGotoes);
    reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional16_terminal_or_prod_priority,1,terminal_or_prod_priority_optional16Gotoes);
    reducepriority_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priority_def,4,priorityGotoes);
    reduceproduction_version = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_version,2,production_versionGotoes);
    reducestart_non_terminals_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_non_terminals_def,3,start_non_terminalsGotoes);
    reduceqmark_optional21_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional21_empty,0,qmark_optional21Gotoes);
    reducetypes_lhs_optional7_types_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.types_lhs_optional7_types_lhs,1,types_lhs_optional7Gotoes);
    reduceblank_lhs_optional3_blank_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lhs_optional3_blank_lhs,1,blank_lhs_optional3Gotoes);
    reduceblank_lexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lexem_terminal,3,blank_lexemGotoes);
    reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional15_terminal_or_prod_priority,1,terminal_or_prod_priority_optional15Gotoes);
    reducedirective_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directive_def,1,directiveGotoes);
    reduceproduction_id = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_id,4,production_idGotoes);
    reduceimport_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.import_list_rec,2,import_listGotoes);
    reduceproduction_version_optional20_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_version_optional20_empty,0,production_version_optional20Gotoes);
    reduceterminal_or_prod_priority_optional15_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional15_empty,0,terminal_or_prod_priority_optional15Gotoes);
    reducetypes_lhs_optional7_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.types_lhs_optional7_empty,0,types_lhs_optional7Gotoes);
    reduceregex_doublequote = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_doublequote,3,regexGotoes);
    reduceseparator_optional26_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional26_empty,0,separator_optional26Gotoes);
    reduceerror_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.error_def,3,error_lhsGotoes);
    reducevariable_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.variable_terminal,3,variableGotoes);
    reducealias_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.alias_def,3,aliasGotoes);
    reducetype_optional11_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional11_empty,0,type_optional11Gotoes);
    reduceterminal_or_prod_priority_optional18_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional18_terminal_or_prod_priority,1,terminal_or_prod_priority_optional18Gotoes);
    reducevargroup_element = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vargroup_element,1,vargroupGotoes);
    reduceimports_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.imports_def,3,imports_lhsGotoes);
    reduceregex_quote = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_quote,3,regexGotoes);
    reducevartype_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vartype_def,2,vartypedefGotoes);
    reducepriorities_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priorities_def,3,priorities_lhsGotoes);
    reducetoken_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.token_def,3,token_lhsGotoes);
    reduceseparator_optional24_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional24_separator,1,separator_optional24Gotoes);
    reducevariable_nonterminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.variable_nonterminal,1,variableGotoes);
    reduceseparator_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_terminal,4,separatorGotoes);
    reduceblanks_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blanks_list_empty,0,blanks_listGotoes);
    reduceproduction_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_def,3,production_lhsGotoes);
    reducedirectives_lhs_optional0_directives_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directives_lhs_optional0_directives_lhs,1,directives_lhs_optional0Gotoes);
    reduceterminal_or_prod_priority_optional18_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional18_empty,0,terminal_or_prod_priority_optional18Gotoes);
    reduceseparator_optional26_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional26_separator,1,separator_optional26Gotoes);
    reduceversion_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.version_list_empty,0,version_listGotoes);
    reducestarts_list_element = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.starts_list_element,1,starts_listGotoes);
    reduceimport_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.import_list_empty,0,import_listGotoes);
    reduceparent_version_optional9_parent_version = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.parent_version_optional9_parent_version,1,parent_version_optional9Gotoes);
    reduceparent_version_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.parent_version_def,2,parent_versionGotoes);
    reducealias_optional10_alias = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.alias_optional10_alias,1,alias_optional10Gotoes);
    reducevar_group = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_group,3,varGotoes);
    reduceblanks_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blanks_list_rec,2,blanks_listGotoes);
    reducepriorities_lhs_optional2_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priorities_lhs_optional2_empty,0,priorities_lhs_optional2Gotoes);
    reduceproduction_id_optional19_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_id_optional19_empty,0,production_id_optional19Gotoes);
    reducebranch_lexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_lexem_terminal,3,branch_lexemGotoes);
    reduceproduction_id_optional19_production_id = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_id_optional19_production_id,1,production_id_optional19Gotoes);
    reduceqmark_optional22_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional22_empty,0,qmark_optional22Gotoes);
    reduceparent_version_optional9_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.parent_version_optional9_empty,0,parent_version_optional9Gotoes);
    reducepriority_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priority_list_empty,0,priority_listGotoes);
    reducetype_optional11_type = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional11_type,1,type_optional11Gotoes);
    reduceregex_terminal_decl_optional12_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_terminal_decl_optional12_empty,0,regex_terminal_decl_optional12Gotoes);
    reducevarlist_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.varlist_empty,0,varlistGotoes);
    reduceproduction_version_optional20_production_version = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_version_optional20_production_version,1,production_version_optional20Gotoes);
    reducevar_nonterminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_nonterminal,2,varGotoes);
    reducedirective_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directive_list_rec,2,directive_listGotoes);
    reduceregex_terminal_decl = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_terminal_decl,2,regex_terminal_declGotoes);
    reduceregex_terminal_decl_optional12_regex_terminal_decl = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_terminal_decl_optional12_regex_terminal_decl,1,regex_terminal_decl_optional12Gotoes);
    reducetype_optional17_type = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional17_type,1,type_optional17Gotoes);
    reducebranch_lhs_optional4_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_lhs_optional4_empty,0,branch_lhs_optional4Gotoes);
    reducepriorities_lhs_optional2_priorities_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priorities_lhs_optional2_priorities_lhs,1,priorities_lhs_optional2Gotoes);
    reducevar_terminal_plus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_terminal_plus,5,varGotoes);
    reducestart_non_terminals_optional8_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_non_terminals_optional8_empty,0,start_non_terminals_optional8Gotoes);
    reducetokens_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.tokens_list_empty,0,tokens_listGotoes);
    reduceprods_element = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.prods_element,1,prodsGotoes);
    reducebranch_eof_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_eof_terminal,2,branch_lexemGotoes);
    reduceblank_lexem_macro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lexem_macro,4,blank_lexemGotoes);
    reducebanches_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.banches_list_rec,2,banches_listGotoes);
    reducetype_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_def,2,typeGotoes);
    reduceblank_lhs_optional3_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lhs_optional3_empty,0,blank_lhs_optional3Gotoes);
    reducevar_nonterminal_plus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_nonterminal_plus,3,varGotoes);
    reduceprod_production = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.prod_production,3,prodGotoes);
    reduceterminal_or_prod_priority_optional16_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional16_empty,0,terminal_or_prod_priority_optional16Gotoes);
    reducedecl_productions = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.decl_productions,5,declGotoes);
    reducevar_terminal_star = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_terminal_star,5,varGotoes);
    reducedirective_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directive_list_empty,0,directive_listGotoes);
    reducelexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.lexem_terminal,5,lexemGotoes);
    reduceimports_lhs_optional1_imports_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.imports_lhs_optional1_imports_lhs,1,imports_lhs_optional1Gotoes);
    reduceseparator_optional25_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional25_empty,0,separator_optional25Gotoes);
    reduceseparator_non_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_non_terminal,2,separatorGotoes);
    reducestart_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_def,11,startGotoes);
    reduceversion_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.version_list_rec,2,version_listGotoes);
    reducetype_optional14_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional14_empty,0,type_optional14Gotoes);
    reducebanches_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.banches_list_empty,0,banches_listGotoes);
    reducedirectives_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directives_def,3,directives_lhsGotoes);
    reduceterminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority,3,terminal_or_prod_priorityGotoes);
    reducevarlist_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.varlist_rec,2,varlistGotoes);
    reduceimports_lhs_optional1_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.imports_lhs_optional1_empty,0,imports_lhs_optional1Gotoes);
    reduceqmark_optional21_qmark = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional21_qmark,1,qmark_optional21Gotoes);
    reducetype_optional17_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional17_empty,0,type_optional17Gotoes);
    reduceterminal_or_prod_priority_optional13_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional13_empty,0,terminal_or_prod_priority_optional13Gotoes);
    reducetype_optional14_type = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional14_type,1,type_optional14Gotoes);
    reducealias_optional10_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.alias_optional10_empty,0,alias_optional10Gotoes);
    reduceseparator_optional25_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional25_separator,1,separator_optional25Gotoes);
    reduceseparator_optional24_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional24_empty,0,separator_optional24Gotoes);
    reducedirectives_lhs_optional0_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directives_lhs_optional0_empty,0,directives_lhs_optional0Gotoes);
    reducestartid_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.startid_def,1,startidGotoes);
    reduceseparator_optional23_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional23_separator,1,separator_optional23Gotoes);
    reducedecls_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.decls_rec,2,declsGotoes);
    reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional13_terminal_or_prod_priority,1,terminal_or_prod_priority_optional13Gotoes);
    reducepriority_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priority_list_rec,2,priority_listGotoes);
    reducestarts_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.starts_list_rec,2,starts_listGotoes);
    reduceimport_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.import_def,1,import_Gotoes);
    reduceversion_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.version_def,2,versionGotoes);
    reducevartypedef_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vartypedef_list_rec,2,vartypedef_listGotoes);
    reducebranch_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_def,3,branch_lhsGotoes);
    reducetypes_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.types_def,3,types_lhsGotoes);
    reduceqmark_optional22_qmark = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional22_qmark,1,qmark_optional22Gotoes);
    reducebranch_lhs_optional4_branch_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_lhs_optional4_branch_lhs,1,branch_lhs_optional4Gotoes);
    reducedecls_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.decls_empty,0,declsGotoes);
    reducevargroup_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vargroup_rec,2,vargroupGotoes);
    reducelexem_macro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.lexem_macro,4,lexemGotoes);
    reduceversions_optional6_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.versions_optional6_empty,0,versions_optional6Gotoes);
    reducevartypedef_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vartypedef_list_empty,0,vartypedef_listGotoes);
    reducetokens_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.tokens_list_rec,2,tokens_listGotoes);
    reducestart_non_terminals_optional8_start_non_terminals = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_non_terminals_optional8_start_non_terminals,1,start_non_terminals_optional8Gotoes);
    reduceerror_lhs_optional5_error_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.error_lhs_optional5_error_lhs,1,error_lhs_optional5Gotoes);
    reduceversions_optional6_versions = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.versions_optional6_versions,1,versions_optional6Gotoes);
    reduceerror_lhs_optional5_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.error_lhs_optional5_empty,0,error_lhs_optional5Gotoes);
    reduceprods_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.prods_rec,3,prodsGotoes);
    reduceseparator_optional23_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional23_empty,0,separator_optional23Gotoes);
    reduceversions_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.versions_def,3,versionsGotoes);
    shift86 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(86);
    shift134 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(134);
    shift142 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(142);
    shift46 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(46);
    shift53 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(53);
    shift131 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(131);
    shift137 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(137);
    shift65 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(65);
    shift21 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(21);
    shift136 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(136);
    shift113 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(113);
    shift39 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(39);
    shift52 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(52);
    shift152 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(152);
    shift96 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(96);
    shift92 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(92);
    shift34 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(34);
    shift13 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(13);
    shift135 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(135);
    shift145 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(145);
    shift35 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(35);
    shift29 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(29);
    shift127 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(127);
    shift123 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(123);
    shift40 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(40);
    shift60 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(60);
    shift106 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(106);
    shift91 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(91);
    shift139 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(139);
    shift22 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(22);
    shift67 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(67);
    shift76 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(76);
    shift2 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(2);
    shift42 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(42);
    shift87 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(87);
    shift156 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(156);
    shift95 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(95);
    shift1 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(1);
    shift27 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(27);
    shift31 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(31);
    shift150 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(150);
    shift138 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(138);
    shift120 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(120);
    shift167 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(167);
    shift32 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(32);
    shift30 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(30);
    shift17 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(17);
    shift88 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(88);
    shift73 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(73);
    shift107 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(107);
    shift19 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(19);
    shift63 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(63);
    shift140 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(140);
    shift10 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(10);
    shift105 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(105);
    shift163 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(163);
    shift4 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(4);
    shift33 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(33);
    shift148 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(148);
    shift16 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(16);
    shift20 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(20);
    shift164 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(164);
    shift125 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(125);
    shift36 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(36);
    shift61 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(61);
    shift104 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(104);
    shift26 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(26);
    shift79 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(79);
    shift94 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(94);
    shift101 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(101);
    shift41 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(41);
    shift51 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(51);
    shift147 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(147);
    shift37 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(37);
    shift114 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(114);
    shift48 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(48);
    shift102 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(102);
    shift121 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(121);
    shift74 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(74);
    shift162 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(162);
    shift45 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(45);
    shift68 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(68);
    shift64 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(64);
    shift165 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(165);
    shift133 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(133);
    shift115 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(115);
    shift11 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(11);
    shift132 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(132);
    shift128 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(128);
    error0 = new ErrorAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    branch0 = new BranchAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    initbranchesdeclArray();
    initeofArray();
    initqmarkArray();
    initplusArray();
    initblanksdeclArray();
    initregexquoteArray();
    initlparArray();
    initidArray();
    initqualifiedidArray();
    initstarArray();
    initprioritiesdeclArray();
    initimportsdeclArray();
    initslashArray();
    initregexdoublequoteArray();
    initrparArray();
    initdirectivesdeclArray();
    initlbracketArray();
    initlsqbracketArray();
    init__eof__Array();
    initsemicolonArray();
    initdollarArray();
    initrsqbracketArray();
    initassocArray();
    initdoublequoteArray();
    initquoted_nameArray();
    initassignArray();
    initnumberArray();
    initerrordeclArray();
    initpipeArray();
    inittypesdeclArray();
    initquoteArray();
    initstartsdeclArray();
    initversionsdeclArray();
    inittokensdeclArray();
    initrbracketArray();
    initproductionsdeclArray();
    initcolonArray();
    EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]> tableMap =
      new EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]>(TerminalEnum.class);

    tableMap.put(TerminalEnum.branchesdecl,branchesdeclArray);
    tableMap.put(TerminalEnum.eof,eofArray);
    tableMap.put(TerminalEnum.qmark,qmarkArray);
    tableMap.put(TerminalEnum.plus,plusArray);
    tableMap.put(TerminalEnum.blanksdecl,blanksdeclArray);
    tableMap.put(TerminalEnum.regexquote,regexquoteArray);
    tableMap.put(TerminalEnum.lpar,lparArray);
    tableMap.put(TerminalEnum.id,idArray);
    tableMap.put(TerminalEnum.qualifiedid,qualifiedidArray);
    tableMap.put(TerminalEnum.star,starArray);
    tableMap.put(TerminalEnum.prioritiesdecl,prioritiesdeclArray);
    tableMap.put(TerminalEnum.importsdecl,importsdeclArray);
    tableMap.put(TerminalEnum.slash,slashArray);
    tableMap.put(TerminalEnum.regexdoublequote,regexdoublequoteArray);
    tableMap.put(TerminalEnum.rpar,rparArray);
    tableMap.put(TerminalEnum.directivesdecl,directivesdeclArray);
    tableMap.put(TerminalEnum.lbracket,lbracketArray);
    tableMap.put(TerminalEnum.lsqbracket,lsqbracketArray);
    tableMap.put(TerminalEnum.__eof__,__eof__Array);
    tableMap.put(TerminalEnum.semicolon,semicolonArray);
    tableMap.put(TerminalEnum.dollar,dollarArray);
    tableMap.put(TerminalEnum.rsqbracket,rsqbracketArray);
    tableMap.put(TerminalEnum.assoc,assocArray);
    tableMap.put(TerminalEnum.doublequote,doublequoteArray);
    tableMap.put(TerminalEnum.quoted_name,quoted_nameArray);
    tableMap.put(TerminalEnum.assign,assignArray);
    tableMap.put(TerminalEnum.number,numberArray);
    tableMap.put(TerminalEnum.errordecl,errordeclArray);
    tableMap.put(TerminalEnum.pipe,pipeArray);
    tableMap.put(TerminalEnum.typesdecl,typesdeclArray);
    tableMap.put(TerminalEnum.quote,quoteArray);
    tableMap.put(TerminalEnum.startsdecl,startsdeclArray);
    tableMap.put(TerminalEnum.versionsdecl,versionsdeclArray);
    tableMap.put(TerminalEnum.tokensdecl,tokensdeclArray);
    tableMap.put(TerminalEnum.rbracket,rbracketArray);
    tableMap.put(TerminalEnum.productionsdecl,productionsdeclArray);
    tableMap.put(TerminalEnum.colon,colonArray);

    initBranchArrayTable();

    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0directive = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directive);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0qualifiedid = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.qualifiedid);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0terminal_or_prod_priority_optional13 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional13);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lpar = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lpar);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0branch_lhs_optional4 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.branch_lhs_optional4);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0alias_optional10 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.alias_optional10);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0types_lhs_optional7 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.types_lhs_optional7);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0start_non_terminals_optional8 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.start_non_terminals_optional8);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0qmark_optional22 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.qmark_optional22);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0regex_terminal_decl_optional12 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex_terminal_decl_optional12);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0prod = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.prod);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0startid = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.startid);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0plus = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.plus);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0startsdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.startsdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0type_optional17 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type_optional17);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0pipe = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.pipe);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0priorities_lhs_optional2 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priorities_lhs_optional2);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0quote = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0separator = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0alias = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.alias);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0types_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.types_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0number = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.number);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0doublequote = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.doublequote);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0star = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.star);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0rpar = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rpar);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0decls = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.decls);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0varlist = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.varlist);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0productionsdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.productionsdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0separator_optional25 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional25);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0prioritiesdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.prioritiesdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0terminal_or_prod_priority_optional15 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional15);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0rsqbracket = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rsqbracket);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0branchesdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.branchesdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0production_id_optional19 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_id_optional19);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0type_optional11 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type_optional11);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0vartypedef = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.vartypedef);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0directives_lhs_optional0 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directives_lhs_optional0);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0colon = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0terminal_or_prod_priority_optional18 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional18);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0versions_optional6 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.versions_optional6);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0blank_lhs_optional3 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blank_lhs_optional3);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0imports_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.imports_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0version = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.version);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0dollar = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dollar);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0parent_version_optional9 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.parent_version_optional9);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0decl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.decl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0priorities_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priorities_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0id = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0semicolon = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.semicolon);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0variable = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.variable);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0regexquote = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.regexquote);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0error_lhs_optional5 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.error_lhs_optional5);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0slash = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.slash);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0quoted_name = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quoted_name);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0var = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.var);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0production_version = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_version);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0assoc = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.assoc);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0prods = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.prods);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0blanksdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.blanksdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0production_id = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_id);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0token_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.token_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0terminal_or_prod_priority = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0starts_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.starts_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0eof = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.eof);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0blanks_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blanks_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0terminal_or_prod_priority_optional16 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional16);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0tokens_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.tokens_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0versionsdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.versionsdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0directivesdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.directivesdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0version_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.version_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lsqbracket = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lsqbracket);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0qmark_optional21 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.qmark_optional21);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0regex_terminal_decl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex_terminal_decl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0branch_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.branch_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0qmark = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.qmark);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0__eof__ = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.__eof__);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lbracket = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbracket);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0start_non_terminals = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.start_non_terminals);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0import_ = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.import_);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0separator_optional23 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional23);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0branch_lexem = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.branch_lexem);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0blank_lexem = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blank_lexem);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0error_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.error_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0priority = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priority);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0rbracket = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbracket);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0vartypedef_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.vartypedef_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0priority_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priority_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0parent_version = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.parent_version);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0blank_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blank_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0directives_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directives_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0vargroup = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.vargroup);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0typesdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.typesdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0import_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.import_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0production_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_lhs);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0importsdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.importsdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0production_version_optional20 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_version_optional20);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(null);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0regexdoublequote = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.regexdoublequote);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0separator_optional24 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional24);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0type_optional14 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type_optional14);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0versions = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.versions);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0errordecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.errordecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0assign = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.assign);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lexem = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.lexem);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0start = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.start);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0imports_lhs_optional1 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.imports_lhs_optional1);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0tokensdecl = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.tokensdecl);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0type = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0directive_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directive_list);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0separator_optional26 = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional26);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0regex = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0banches_list = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.banches_list);

    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum>[] tableMetadata = (StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum>[])new StateMetadata<?,?,?>[]{metadata0null, metadata0directivesdecl, metadata0colon, metadata0directive_list, metadata0id, metadata0directive, metadata0start, metadata0__eof__, metadata0directives_lhs, metadata0directives_lhs_optional0, metadata0importsdecl, metadata0colon, metadata0import_list, metadata0qualifiedid, metadata0import_, metadata0imports_lhs_optional1, metadata0prioritiesdecl, metadata0colon, metadata0priority_list, metadata0id, metadata0assign, metadata0number, metadata0assoc, metadata0priority, metadata0priorities_lhs, metadata0priorities_lhs_optional2, metadata0tokensdecl, metadata0colon, metadata0tokens_list, metadata0dollar, metadata0id, metadata0assign, metadata0doublequote, metadata0regexdoublequote, metadata0doublequote, metadata0quote, metadata0regexquote, metadata0quote, metadata0regex, metadata0id, metadata0lpar, metadata0quoted_name, metadata0rpar, metadata0alias, metadata0alias_optional10, metadata0colon, metadata0qualifiedid, metadata0type_optional11, metadata0assign, metadata0regex, metadata0regex_terminal_decl_optional12, metadata0lsqbracket, metadata0id, metadata0rsqbracket, metadata0terminal_or_prod_priority, metadata0terminal_or_prod_priority_optional13, metadata0regex_terminal_decl, metadata0type, metadata0lexem, metadata0token_lhs, metadata0blanksdecl, metadata0colon, metadata0blanks_list, metadata0dollar, metadata0id, metadata0assign, metadata0regex, metadata0id, metadata0assign, metadata0regex, metadata0blank_lexem, metadata0blank_lhs, metadata0blank_lhs_optional3, metadata0branchesdecl, metadata0colon, metadata0banches_list, metadata0eof, metadata0terminal_or_prod_priority, metadata0terminal_or_prod_priority_optional16, metadata0id, metadata0type_optional14, metadata0terminal_or_prod_priority, metadata0terminal_or_prod_priority_optional15, metadata0type, metadata0branch_lexem, metadata0branch_lhs_optional4, metadata0errordecl, metadata0colon, metadata0id, metadata0error_lhs, metadata0error_lhs_optional5, metadata0versionsdecl, metadata0colon, metadata0version_list, metadata0id, metadata0colon, metadata0id, metadata0parent_version, metadata0parent_version_optional9, metadata0version, metadata0versions_optional6, metadata0typesdecl, metadata0colon, metadata0vartypedef_list, metadata0quote, metadata0id, metadata0quote, metadata0id, metadata0vartypedef, metadata0variable, metadata0type, metadata0types_lhs, metadata0types_lhs_optional7, metadata0startsdecl, metadata0colon, metadata0id, metadata0startid, metadata0starts_list, metadata0startid, metadata0start_non_terminals_optional8, metadata0productionsdecl, metadata0colon, metadata0decls, metadata0id, metadata0type_optional17, metadata0assign, metadata0prods, metadata0semicolon, metadata0pipe, metadata0prod, metadata0varlist, metadata0lpar, metadata0quote, metadata0id, metadata0quote, metadata0qmark, metadata0slash, metadata0quote, metadata0id, metadata0quote, metadata0id, metadata0separator_optional23, metadata0star, metadata0qmark_optional21, metadata0separator_optional24, metadata0plus, metadata0separator, metadata0id, metadata0qmark, metadata0separator_optional25, metadata0star, metadata0separator_optional26, metadata0plus, metadata0qmark_optional22, metadata0separator, metadata0vargroup, metadata0rpar, metadata0var, metadata0var, metadata0terminal_or_prod_priority, metadata0var, metadata0terminal_or_prod_priority_optional18, metadata0lbracket, metadata0id, metadata0colon, metadata0id, metadata0production_version_optional20, metadata0rbracket, metadata0production_version, metadata0production_id_optional19, metadata0production_id, metadata0prod, metadata0type, metadata0decl, metadata0production_lhs, metadata0start_non_terminals, metadata0versions, metadata0branch_lhs, metadata0imports_lhs};
    
    EnumMap<NonTerminalEnum,Integer> tableStarts =
      new EnumMap<NonTerminalEnum,Integer>(NonTerminalEnum.class);
    tableStarts.put(NonTerminalEnum.start,0);
    table = new ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>(tableMap,branchArrayTable,tableMetadata,tableStarts,VersionEnum.values(),179,TerminalEnum.__eof__, null);
  } 
  

  private int[] production_id_optional19Gotoes;

  private void initproduction_id_optional19Gotoes() {
    production_id_optional19Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 169, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] start_non_terminals_optional8Gotoes;

  private void initstart_non_terminals_optional8Gotoes() {
    start_non_terminals_optional8Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 119, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] varGotoes;

  private void initvarGotoes() {
    varGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 160, 158, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 157, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] blank_lhsGotoes;

  private void initblank_lhsGotoes() {
    blank_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 71, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] priority_listGotoes;

  private void initpriority_listGotoes() {
    priority_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 18, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] terminal_or_prod_priority_optional18Gotoes;

  private void initterminal_or_prod_priority_optional18Gotoes() {
    terminal_or_prod_priority_optional18Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 161, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] directives_lhsGotoes;

  private void initdirectives_lhsGotoes() {
    directives_lhsGotoes = 
      new int[]{8, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] production_lhsGotoes;

  private void initproduction_lhsGotoes() {
    production_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 174, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] start_non_terminalsGotoes;

  private void initstart_non_terminalsGotoes() {
    start_non_terminalsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 175, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] branch_lhsGotoes;

  private void initbranch_lhsGotoes() {
    branch_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 177, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] startidGotoes;

  private void initstartidGotoes() {
    startidGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 116, -1, -1, 118, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] regexGotoes;

  private void initregexGotoes() {
    regexGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 38, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 49, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 66, -1, -1, 69, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] token_lhsGotoes;

  private void inittoken_lhsGotoes() {
    token_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 59, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] error_lhs_optional5Gotoes;

  private void initerror_lhs_optional5Gotoes() {
    error_lhs_optional5Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 90, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] prodsGotoes;

  private void initprodsGotoes() {
    prodsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 126, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] tokens_listGotoes;

  private void inittokens_listGotoes() {
    tokens_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 28, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] regex_terminal_declGotoes;

  private void initregex_terminal_declGotoes() {
    regex_terminal_declGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 56, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] qmark_optional22Gotoes;

  private void initqmark_optional22Gotoes() {
    qmark_optional22Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 153, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] separatorGotoes;

  private void initseparatorGotoes() {
    separatorGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 146, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 154, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] priorityGotoes;

  private void initpriorityGotoes() {
    priorityGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 23, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] separator_optional23Gotoes;

  private void initseparator_optional23Gotoes() {
    separator_optional23Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 141, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] aliasGotoes;

  private void initaliasGotoes() {
    aliasGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 43, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] variableGotoes;

  private void initvariableGotoes() {
    variableGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 109, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] type_optional11Gotoes;

  private void inittype_optional11Gotoes() {
    type_optional11Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 47, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] lexemGotoes;

  private void initlexemGotoes() {
    lexemGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 58, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] production_idGotoes;

  private void initproduction_idGotoes() {
    production_idGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 170, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] prodGotoes;

  private void initprodGotoes() {
    prodGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 171, -1, -1, 129, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] separator_optional26Gotoes;

  private void initseparator_optional26Gotoes() {
    separator_optional26Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 151, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] type_optional14Gotoes;

  private void inittype_optional14Gotoes() {
    type_optional14Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 80, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] alias_optional10Gotoes;

  private void initalias_optional10Gotoes() {
    alias_optional10Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 44, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] import_listGotoes;

  private void initimport_listGotoes() {
    import_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 12, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] priorities_lhs_optional2Gotoes;

  private void initpriorities_lhs_optional2Gotoes() {
    priorities_lhs_optional2Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 25, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] error_lhsGotoes;

  private void initerror_lhsGotoes() {
    error_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 89, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] types_lhsGotoes;

  private void inittypes_lhsGotoes() {
    types_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 111, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] production_version_optional20Gotoes;

  private void initproduction_version_optional20Gotoes() {
    production_version_optional20Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 166, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] versionGotoes;

  private void initversionGotoes() {
    versionGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 99, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] separator_optional24Gotoes;

  private void initseparator_optional24Gotoes() {
    separator_optional24Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 144, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] parent_versionGotoes;

  private void initparent_versionGotoes() {
    parent_versionGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 97, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] priorities_lhsGotoes;

  private void initpriorities_lhsGotoes() {
    priorities_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 24, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] banches_listGotoes;

  private void initbanches_listGotoes() {
    banches_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 75, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] declGotoes;

  private void initdeclGotoes() {
    declGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 173, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] vartypedefGotoes;

  private void initvartypedefGotoes() {
    vartypedefGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 108, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] branch_lhs_optional4Gotoes;

  private void initbranch_lhs_optional4Gotoes() {
    branch_lhs_optional4Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 85, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] vartypedef_listGotoes;

  private void initvartypedef_listGotoes() {
    vartypedef_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 103, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] imports_lhs_optional1Gotoes;

  private void initimports_lhs_optional1Gotoes() {
    imports_lhs_optional1Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] versions_optional6Gotoes;

  private void initversions_optional6Gotoes() {
    versions_optional6Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 100, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] starts_listGotoes;

  private void initstarts_listGotoes() {
    starts_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 117, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] varlistGotoes;

  private void initvarlistGotoes() {
    varlistGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 130, -1, -1, 130, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] vargroupGotoes;

  private void initvargroupGotoes() {
    vargroupGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 155, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] blanks_listGotoes;

  private void initblanks_listGotoes() {
    blanks_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] terminal_or_prod_priority_optional15Gotoes;

  private void initterminal_or_prod_priority_optional15Gotoes() {
    terminal_or_prod_priority_optional15Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 82, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] separator_optional25Gotoes;

  private void initseparator_optional25Gotoes() {
    separator_optional25Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 149, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] terminal_or_prod_priority_optional16Gotoes;

  private void initterminal_or_prod_priority_optional16Gotoes() {
    terminal_or_prod_priority_optional16Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 78, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] regex_terminal_decl_optional12Gotoes;

  private void initregex_terminal_decl_optional12Gotoes() {
    regex_terminal_decl_optional12Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 50, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] branch_lexemGotoes;

  private void initbranch_lexemGotoes() {
    branch_lexemGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 84, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] types_lhs_optional7Gotoes;

  private void inittypes_lhs_optional7Gotoes() {
    types_lhs_optional7Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 112, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] production_versionGotoes;

  private void initproduction_versionGotoes() {
    production_versionGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 168, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] terminal_or_prod_priorityGotoes;

  private void initterminal_or_prod_priorityGotoes() {
    terminal_or_prod_priorityGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 54, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 77, -1, -1, -1, 81, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 159, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] directive_listGotoes;

  private void initdirective_listGotoes() {
    directive_listGotoes = 
      new int[]{-1, -1, 3, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] terminal_or_prod_priority_optional13Gotoes;

  private void initterminal_or_prod_priority_optional13Gotoes() {
    terminal_or_prod_priority_optional13Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 55, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] declsGotoes;

  private void initdeclsGotoes() {
    declsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 122, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] versionsGotoes;

  private void initversionsGotoes() {
    versionsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 176, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] startGotoes;

  private void initstartGotoes() {
    startGotoes = 
      new int[]{6, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] directives_lhs_optional0Gotoes;

  private void initdirectives_lhs_optional0Gotoes() {
    directives_lhs_optional0Gotoes = 
      new int[]{9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] type_optional17Gotoes;

  private void inittype_optional17Gotoes() {
    type_optional17Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 124, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] import_Gotoes;

  private void initimport_Gotoes() {
    import_Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 14, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] version_listGotoes;

  private void initversion_listGotoes() {
    version_listGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 93, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] blank_lhs_optional3Gotoes;

  private void initblank_lhs_optional3Gotoes() {
    blank_lhs_optional3Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 72, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] qmark_optional21Gotoes;

  private void initqmark_optional21Gotoes() {
    qmark_optional21Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 143, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] imports_lhsGotoes;

  private void initimports_lhsGotoes() {
    imports_lhsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, 178, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] blank_lexemGotoes;

  private void initblank_lexemGotoes() {
    blank_lexemGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 70, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] typeGotoes;

  private void inittypeGotoes() {
    typeGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 57, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 83, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 110, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 172, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] directiveGotoes;

  private void initdirectiveGotoes() {
    directiveGotoes = 
      new int[]{-1, -1, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] parent_version_optional9Gotoes;

  private void initparent_version_optional9Gotoes() {
    parent_version_optional9Gotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 98, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchesdeclArray;
  @SuppressWarnings("unchecked")
  private void initbranchesdeclArray() {
    branchesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, reduceblank_lhs_optional3_empty, branch0, reduceblanks_list_empty, reduceblank_def, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, reduceblank_lhs_optional3_blank_lhs, shift73, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] eofArray;
  @SuppressWarnings("unchecked")
  private void initeofArray() {
    eofArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetype_def, branch0, branch0, branch0, branch0, branch0, branch0, reduceterminal_or_prod_priority, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducebanches_list_empty, shift76, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] qmarkArray;
  @SuppressWarnings("unchecked")
  private void initqmarkArray() {
    qmarkArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift135, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift148, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] plusArray;
  @SuppressWarnings("unchecked")
  private void initplusArray() {
    plusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceseparator_optional24_empty, branch0, branch0, branch0, branch0, reduceseparator_terminal, reduceseparator_non_terminal, branch0, branch0, branch0, shift145, branch0, reduceseparator_optional24_separator, reduceseparator_optional26_empty, branch0, branch0, branch0, shift152, branch0, branch0, reduceseparator_optional26_separator, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] blanksdeclArray;
  @SuppressWarnings("unchecked")
  private void initblanksdeclArray() {
    blanksdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, shift60, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] regexquoteArray;
  @SuppressWarnings("unchecked")
  private void initregexquoteArray() {
    regexquoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift36, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lparArray;
  @SuppressWarnings("unchecked")
  private void initlparArray() {
    lparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift40, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevarlist_empty, branch0, branch0, reducevarlist_empty, branch0, shift131, shift131, branch0, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, branch0, branch0, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, shift131, reducevar_group, reducevargroup_rec, reducevargroup_element, branch0, reducevarlist_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] idArray;
  @SuppressWarnings("unchecked")
  private void initidArray() {
    idArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, reducedirective_list_empty, shift4, reducedirective_def, reducedirective_list_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducepriority_list_empty, shift19, branch0, branch0, branch0, reducepriority_def, reducepriority_list_rec, branch0, branch0, branch0, reducetokens_list_empty, shift39, shift30, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, shift52, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, branch0, branch0, reduceblanks_list_empty, shift67, shift64, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, branch0, branch0, branch0, reducebanches_list_empty, shift79, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, branch0, branch0, shift88, branch0, branch0, branch0, branch0, reduceversion_list_empty, shift94, reduceparent_version_optional9_empty, shift96, reduceparent_version_def, reduceparent_version_optional9_parent_version, reduceversion_def, reduceversion_list_rec, branch0, branch0, reducevartypedef_list_empty, shift107, shift105, branch0, branch0, branch0, reducevartypedef_list_rec, branch0, reducevartype_def, branch0, branch0, branch0, shift115, reducestartid_def, reducestarts_list_element, shift115, reducestarts_list_rec, branch0, branch0, reducedecls_empty, shift123, branch0, branch0, reducevarlist_empty, branch0, reducedecl_productions, reducevarlist_empty, branch0, shift147, shift147, shift133, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, shift140, shift138, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, shift147, reducevar_group, reducevargroup_rec, reducevargroup_element, branch0, reducevarlist_rec, branch0, shift163, branch0, shift165, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducedecls_rec, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] qualifiedidArray;
  @SuppressWarnings("unchecked")
  private void initqualifiedidArray() {
    qualifiedidArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceimport_list_empty, shift13, reduceimport_def, reduceimport_list_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift46, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] starArray;
  @SuppressWarnings("unchecked")
  private void initstarArray() {
    starArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceseparator_optional23_empty, branch0, branch0, branch0, branch0, reduceseparator_terminal, reduceseparator_non_terminal, shift142, branch0, branch0, branch0, branch0, reduceseparator_optional23_separator, reduceseparator_optional25_empty, branch0, shift150, branch0, branch0, branch0, branch0, reduceseparator_optional25_separator, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] prioritiesdeclArray;
  @SuppressWarnings("unchecked")
  private void initprioritiesdeclArray() {
    prioritiesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{reducedirectives_lhs_optional0_empty, branch0, reducedirective_list_empty, reducedirectives_def, reducedirective_def, reducedirective_list_rec, branch0, branch0, reducedirectives_lhs_optional0_directives_lhs, reduceimports_lhs_optional1_empty, branch0, reduceimport_list_empty, reduceimports_def, reduceimport_def, reduceimport_list_rec, shift16, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceimports_lhs_optional1_imports_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] importsdeclArray;
  @SuppressWarnings("unchecked")
  private void initimportsdeclArray() {
    importsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{reducedirectives_lhs_optional0_empty, branch0, reducedirective_list_empty, reducedirectives_def, reducedirective_def, reducedirective_list_rec, branch0, branch0, reducedirectives_lhs_optional0_directives_lhs, shift10, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] slashArray;
  @SuppressWarnings("unchecked")
  private void initslashArray() {
    slashArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift136, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift136, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] regexdoublequoteArray;
  @SuppressWarnings("unchecked")
  private void initregexdoublequoteArray() {
    regexdoublequoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift33, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rparArray;
  @SuppressWarnings("unchecked")
  private void initrparArray() {
    rparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift42, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, branch0, branch0, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, shift156, reducevar_group, reducevargroup_rec, reducevargroup_element, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] directivesdeclArray;
  @SuppressWarnings("unchecked")
  private void initdirectivesdeclArray() {
    directivesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift1, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbracketArray;
  @SuppressWarnings("unchecked")
  private void initlbracketArray() {
    lbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceterminal_or_prod_priority, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevarlist_empty, branch0, branch0, reducevarlist_empty, branch0, reduceterminal_or_prod_priority_optional18_empty, branch0, branch0, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, branch0, branch0, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, branch0, reducevar_group, branch0, branch0, reduceterminal_or_prod_priority_optional18_terminal_or_prod_priority, reducevarlist_rec, shift162, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lsqbracketArray;
  @SuppressWarnings("unchecked")
  private void initlsqbracketArray() {
    lsqbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, branch0, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, shift51, branch0, branch0, branch0, branch0, branch0, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift51, branch0, branch0, reducetype_optional14_empty, shift51, branch0, branch0, reducetype_optional14_type, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevarlist_empty, branch0, branch0, reducevarlist_empty, branch0, shift51, branch0, branch0, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, branch0, branch0, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, branch0, reducevar_group, branch0, branch0, branch0, reducevarlist_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] __eof__Array;
  @SuppressWarnings("unchecked")
  private void init__eof__Array() {
    __eof__Array=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, accept, accept, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducedecls_empty, reduceproduction_def, branch0, branch0, branch0, branch0, reducedecl_productions, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducedecls_rec, reducestart_def, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] semicolonArray;
  @SuppressWarnings("unchecked")
  private void initsemicolonArray() {
    semicolonArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceterminal_or_prod_priority, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevarlist_empty, shift127, branch0, reducevarlist_empty, reduceprods_rec, reduceterminal_or_prod_priority_optional18_empty, branch0, branch0, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, branch0, branch0, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, branch0, reducevar_group, branch0, branch0, reduceterminal_or_prod_priority_optional18_terminal_or_prod_priority, reducevarlist_rec, reduceproduction_id_optional19_empty, branch0, branch0, branch0, branch0, branch0, reduceproduction_id, branch0, reduceprod_production, reduceproduction_id_optional19_production_id, reduceprods_element, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dollarArray;
  @SuppressWarnings("unchecked")
  private void initdollarArray() {
    dollarArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, shift29, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, branch0, branch0, reduceblanks_list_empty, shift63, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rsqbracketArray;
  @SuppressWarnings("unchecked")
  private void initrsqbracketArray() {
    rsqbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift53, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] assocArray;
  @SuppressWarnings("unchecked")
  private void initassocArray() {
    assocArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift22, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] doublequoteArray;
  @SuppressWarnings("unchecked")
  private void initdoublequoteArray() {
    doublequoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift32, branch0, shift34, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift32, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift32, branch0, branch0, shift32, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoted_nameArray;
  @SuppressWarnings("unchecked")
  private void initquoted_nameArray() {
    quoted_nameArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift41, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] assignArray;
  @SuppressWarnings("unchecked")
  private void initassignArray() {
    assignArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift20, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift31, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, shift48, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetype_optional11_type, branch0, branch0, branch0, branch0, branch0, branch0, shift65, branch0, branch0, shift68, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetype_optional17_empty, shift125, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetype_optional17_type, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] numberArray;
  @SuppressWarnings("unchecked")
  private void initnumberArray() {
    numberArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift21, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] errordeclArray;
  @SuppressWarnings("unchecked")
  private void initerrordeclArray() {
    errordeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, reduceblank_lhs_optional3_empty, branch0, reduceblanks_list_empty, reduceblank_def, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, reduceblank_lhs_optional3_blank_lhs, reducebranch_lhs_optional4_empty, branch0, reducebanches_list_empty, reducebranch_def, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, shift86, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducebranch_lhs_optional4_branch_lhs, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] pipeArray;
  @SuppressWarnings("unchecked")
  private void initpipeArray() {
    pipeArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceterminal_or_prod_priority, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevarlist_empty, shift128, branch0, reducevarlist_empty, reduceprods_rec, reduceterminal_or_prod_priority_optional18_empty, branch0, branch0, branch0, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, branch0, branch0, branch0, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, branch0, reducevar_group, branch0, branch0, reduceterminal_or_prod_priority_optional18_terminal_or_prod_priority, reducevarlist_rec, reduceproduction_id_optional19_empty, branch0, branch0, branch0, branch0, branch0, reduceproduction_id, branch0, reduceprod_production, reduceproduction_id_optional19_production_id, reduceprods_element, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] typesdeclArray;
  @SuppressWarnings("unchecked")
  private void inittypesdeclArray() {
    typesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, reduceblank_lhs_optional3_empty, branch0, reduceblanks_list_empty, reduceblank_def, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, reduceblank_lhs_optional3_blank_lhs, reducebranch_lhs_optional4_empty, branch0, reducebanches_list_empty, reducebranch_def, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, reduceerror_lhs_optional5_empty, branch0, branch0, reduceerror_def, reduceerror_lhs_optional5_error_lhs, reduceversions_optional6_empty, branch0, reduceversion_list_empty, reduceversions_def, reduceparent_version_optional9_empty, branch0, reduceparent_version_def, reduceparent_version_optional9_parent_version, reduceversion_def, reduceversion_list_rec, shift101, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceversions_optional6_versions, reducebranch_lhs_optional4_branch_lhs, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoteArray;
  @SuppressWarnings("unchecked")
  private void initquoteArray() {
    quoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift35, branch0, branch0, branch0, branch0, shift37, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetype_def, branch0, shift35, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift35, branch0, branch0, shift35, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevartypedef_list_empty, shift104, branch0, shift106, branch0, branch0, reducevartypedef_list_rec, branch0, reducevartype_def, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducevarlist_empty, branch0, branch0, reducevarlist_empty, branch0, shift132, shift132, branch0, shift134, reduceqmark_optional21_empty, reduceqmark_optional21_qmark, shift137, branch0, shift139, branch0, branch0, branch0, reducevar_terminal_star, reducevar_terminal, branch0, reducevar_terminal_plus, branch0, reduceqmark_optional22_empty, reduceqmark_optional22_qmark, branch0, reducevar_nonterminal_star, branch0, reducevar_nonterminal_plus, reducevar_nonterminal, branch0, shift132, reducevar_group, reducevargroup_rec, reducevargroup_element, branch0, reducevarlist_rec, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] startsdeclArray;
  @SuppressWarnings("unchecked")
  private void initstartsdeclArray() {
    startsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, reduceblank_lhs_optional3_empty, branch0, reduceblanks_list_empty, reduceblank_def, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, reduceblank_lhs_optional3_blank_lhs, reducebranch_lhs_optional4_empty, branch0, reducebanches_list_empty, reducebranch_def, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, reduceerror_lhs_optional5_empty, branch0, branch0, reduceerror_def, reduceerror_lhs_optional5_error_lhs, reduceversions_optional6_empty, branch0, reduceversion_list_empty, reduceversions_def, reduceparent_version_optional9_empty, branch0, reduceparent_version_def, reduceparent_version_optional9_parent_version, reduceversion_def, reduceversion_list_rec, reducetypes_lhs_optional7_empty, branch0, reducevartypedef_list_empty, reducetypes_def, branch0, branch0, branch0, branch0, reducevartypedef_list_rec, branch0, reducevartype_def, reducetypes_lhs_optional7_types_lhs, shift113, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceversions_optional6_versions, reducebranch_lhs_optional4_branch_lhs, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] versionsdeclArray;
  @SuppressWarnings("unchecked")
  private void initversionsdeclArray() {
    versionsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, reduceblank_lhs_optional3_empty, branch0, reduceblanks_list_empty, reduceblank_def, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, reduceblank_lhs_optional3_blank_lhs, reducebranch_lhs_optional4_empty, branch0, reducebanches_list_empty, reducebranch_def, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, reduceerror_lhs_optional5_empty, branch0, branch0, reduceerror_def, reduceerror_lhs_optional5_error_lhs, shift91, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducebranch_lhs_optional4_branch_lhs, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] tokensdeclArray;
  @SuppressWarnings("unchecked")
  private void inittokensdeclArray() {
    tokensdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{reducedirectives_lhs_optional0_empty, branch0, reducedirective_list_empty, reducedirectives_def, reducedirective_def, reducedirective_list_rec, branch0, branch0, reducedirectives_lhs_optional0_directives_lhs, reduceimports_lhs_optional1_empty, branch0, reduceimport_list_empty, reduceimports_def, reduceimport_def, reduceimport_list_rec, reducepriorities_lhs_optional2_empty, branch0, reducepriority_list_empty, reducepriorities_def, branch0, branch0, branch0, reducepriority_def, reducepriority_list_rec, reducepriorities_lhs_optional2_priorities_lhs, shift26, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceimports_lhs_optional1_imports_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbracketArray;
  @SuppressWarnings("unchecked")
  private void initrbracketArray() {
    rbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceproduction_version_optional20_empty, branch0, reduceproduction_version, shift167, branch0, reduceproduction_version_optional20_production_version, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] productionsdeclArray;
  @SuppressWarnings("unchecked")
  private void initproductionsdeclArray() {
    productionsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducetokens_list_empty, reducetoken_def, branch0, branch0, branch0, branch0, branch0, reduceregex_doublequote, branch0, branch0, reduceregex_quote, reducelexem_macro, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, reducetype_optional11_empty, branch0, reducetype_def, reduceregex_terminal_decl_optional12_empty, branch0, reduceregex_terminal_decl, reduceterminal_or_prod_priority_optional13_empty, branch0, branch0, reduceterminal_or_prod_priority, reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority, reducelexem_terminal, reduceregex_terminal_decl_optional12_regex_terminal_decl, reducetype_optional11_type, reducetokens_list_rec, reduceblank_lhs_optional3_empty, branch0, reduceblanks_list_empty, reduceblank_def, branch0, branch0, branch0, reduceblank_lexem_macro, branch0, branch0, reduceblank_lexem_terminal, reduceblanks_list_rec, reduceblank_lhs_optional3_blank_lhs, reducebranch_lhs_optional4_empty, branch0, reducebanches_list_empty, reducebranch_def, reduceterminal_or_prod_priority_optional16_empty, reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority, reducebranch_eof_terminal, reducetype_optional14_empty, reduceterminal_or_prod_priority_optional15_empty, reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority, reducebranch_lexem_terminal, reducetype_optional14_type, reducebanches_list_rec, reduceerror_lhs_optional5_empty, branch0, branch0, reduceerror_def, reduceerror_lhs_optional5_error_lhs, reduceversions_optional6_empty, branch0, reduceversion_list_empty, reduceversions_def, reduceparent_version_optional9_empty, branch0, reduceparent_version_def, reduceparent_version_optional9_parent_version, reduceversion_def, reduceversion_list_rec, reducetypes_lhs_optional7_empty, branch0, reducevartypedef_list_empty, reducetypes_def, branch0, branch0, branch0, branch0, reducevartypedef_list_rec, branch0, reducevartype_def, reducetypes_lhs_optional7_types_lhs, reducestart_non_terminals_optional8_empty, branch0, branch0, reducestartid_def, reducestarts_list_element, reducestart_non_terminals_def, reducestarts_list_rec, shift120, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducestart_non_terminals_optional8_start_non_terminals, reduceversions_optional6_versions, reducebranch_lhs_optional4_branch_lhs, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] colonArray;
  @SuppressWarnings("unchecked")
  private void initcolonArray() {
    colonArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, shift2, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift11, branch0, branch0, branch0, branch0, branch0, shift17, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift27, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reducealias_optional10_empty, branch0, branch0, reducealias_def, reducealias_optional10_alias, shift45, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift61, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift74, branch0, branch0, branch0, branch0, branch0, shift45, branch0, branch0, branch0, branch0, branch0, branch0, shift87, branch0, branch0, branch0, branch0, shift92, branch0, branch0, shift95, branch0, branch0, branch0, branch0, branch0, branch0, shift102, branch0, branch0, branch0, branch0, reducevariable_terminal, reducevariable_nonterminal, branch0, shift45, branch0, branch0, branch0, shift114, branch0, branch0, branch0, branch0, branch0, branch0, shift121, branch0, branch0, shift45, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift164, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchArrayTable;
  @SuppressWarnings("unchecked")
  private void initBranchArrayTable() {
    branchArrayTable=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{error0, error0, error0, error0, error0, error0, exit, exit, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, reducedecls_empty, reduceproduction_def, error0, error0, error0, error0, reducedecl_productions, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, reducedecls_rec, reducestart_def, error0, error0, error0, error0};
  }

  private final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> table;
  
  public static final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> createTable() {
    return new ParserDataTable().table;
  }

  private final AcceptAction<TerminalEnum,ProductionEnum,VersionEnum> accept;
  private final ExitAction<TerminalEnum,ProductionEnum,VersionEnum> exit;

  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_nonterminal_star;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional16_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriority_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_version;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_non_terminals_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional21_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetypes_lhs_optional7_types_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lhs_optional3_blank_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional15_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirective_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_id;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimport_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_version_optional20_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional15_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetypes_lhs_optional7_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_doublequote;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional26_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceerror_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevariable_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducealias_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional11_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional18_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevargroup_element;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimports_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_quote;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevartype_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriorities_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetoken_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional24_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevariable_nonterminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblanks_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirectives_lhs_optional0_directives_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional18_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional26_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversion_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestarts_list_element;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimport_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceparent_version_optional9_parent_version;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceparent_version_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducealias_optional10_alias;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_group;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblanks_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriorities_lhs_optional2_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_id_optional19_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_lexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_id_optional19_production_id;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional22_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceparent_version_optional9_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriority_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional11_type;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_terminal_decl_optional12_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevarlist_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_version_optional20_production_version;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_nonterminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirective_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_terminal_decl;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_terminal_decl_optional12_regex_terminal_decl;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional17_type;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_lhs_optional4_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriorities_lhs_optional2_priorities_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_terminal_plus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_non_terminals_optional8_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetokens_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceprods_element;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_eof_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lexem_macro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebanches_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lhs_optional3_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_nonterminal_plus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceprod_production;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional16_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedecl_productions;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_terminal_star;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirective_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducelexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimports_lhs_optional1_imports_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional25_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_non_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversion_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional14_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebanches_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirectives_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevarlist_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimports_lhs_optional1_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional21_qmark;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional17_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional13_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional14_type;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducealias_optional10_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional25_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional24_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirectives_lhs_optional0_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestartid_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional23_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedecls_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional13_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriority_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestarts_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimport_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversion_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevartypedef_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetypes_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional22_qmark;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_lhs_optional4_branch_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedecls_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevargroup_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducelexem_macro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversions_optional6_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevartypedef_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetokens_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_non_terminals_optional8_start_non_terminals;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceerror_lhs_optional5_error_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversions_optional6_versions;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceerror_lhs_optional5_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceprods_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional23_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversions_def;

  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift86;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift134;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift142;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift46;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift53;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift131;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift137;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift65;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift21;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift136;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift113;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift39;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift52;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift152;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift96;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift92;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift34;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift13;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift135;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift145;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift35;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift29;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift127;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift123;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift40;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift60;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift106;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift91;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift139;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift22;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift67;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift76;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift2;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift42;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift87;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift156;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift95;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift1;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift27;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift31;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift150;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift138;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift120;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift167;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift32;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift30;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift17;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift88;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift73;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift107;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift19;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift63;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift140;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift10;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift105;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift163;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift4;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift33;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift148;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift16;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift20;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift164;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift125;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift36;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift61;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift104;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift26;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift79;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift94;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift101;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift41;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift51;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift147;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift37;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift114;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift48;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift102;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift121;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift74;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift162;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift45;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift68;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift64;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift165;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift133;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift115;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift11;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift132;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift128;


  private final ErrorAction<TerminalEnum,ProductionEnum,VersionEnum> error0;

  private final BranchAction<TerminalEnum,ProductionEnum,VersionEnum> branch0;

}
