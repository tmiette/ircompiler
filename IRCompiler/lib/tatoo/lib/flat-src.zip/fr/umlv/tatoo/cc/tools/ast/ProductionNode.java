/*
 * Created on 4 mars 2006
 *
 */
package fr.umlv.tatoo.cc.tools.ast;

public interface ProductionNode extends ASTNode {
  //called by velocity
  public boolean isComposite();
}
