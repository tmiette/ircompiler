package fr.umlv.tatoo.cc.lexer.ebnf.parser;

/** 
 *  This class is generated - please do not edit it 
 */
public enum NonTerminalEnum {
  start, directives_lhs, directives_lhs_optional0, imports_lhs, imports_lhs_optional1, priorities_lhs, priorities_lhs_optional2, token_lhs, blank_lhs, blank_lhs_optional3, branch_lhs, branch_lhs_optional4, error_lhs, error_lhs_optional5, versions, versions_optional6, types_lhs, types_lhs_optional7, start_non_terminals, start_non_terminals_optional8, production_lhs, directive, directive_list, lexem, tokens_list, decl, decls, blank_lexem, blanks_list, branch_lexem, banches_list, import_, import_list, priority, priority_list, version, version_list, parent_version, parent_version_optional9, vartypedef, vartypedef_list, variable, type, regex, alias, alias_optional10, type_optional11, regex_terminal_decl, regex_terminal_decl_optional12, terminal_or_prod_priority, terminal_or_prod_priority_optional13, type_optional14, terminal_or_prod_priority_optional15, terminal_or_prod_priority_optional16, startid, starts_list, type_optional17, prod, prods, var, varlist, terminal_or_prod_priority_optional18, production_id, production_id_optional19, production_version, production_version_optional20, vargroup, qmark_optional21, qmark_optional22, separator, separator_optional23, separator_optional24, separator_optional25, separator_optional26;
}