package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

/** 
 *  This class is generated - please do not edit it 
 */
public enum VersionEnum {
  DEFAULT;
}