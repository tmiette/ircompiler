package fr.umlv.tatoo.runtime.lexer;

public enum ForwardReturn {
  DISCARD,RETRY
}
