package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

/** 
 *  This class is generated - please do not edit it 
 */
public enum TerminalEnum {
  plus, star, question, minus, slash, comma, hat, dollar, pipe, integer, lbrac, rbrac, lpar, rpar, lbrak, rbrak, quote, dot, name, specialLetter, normalLetter, stringLetter, intervalLetter, __eof__;
}