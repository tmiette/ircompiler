package fr.umlv.tatoo.cc.lexer.ebnf.tools;

import fr.umlv.tatoo.cc.ebnf.ast.AliasDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.DirectiveDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.ImportDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.NodeAST;
import fr.umlv.tatoo.cc.ebnf.ast.NonTerminalDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.PriorityDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.PriorityVarAST;
import fr.umlv.tatoo.cc.ebnf.ast.ProductionIdAndVersionDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.RootDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.SimpleNodeAST;
import fr.umlv.tatoo.cc.ebnf.ast.StartNonTerminalSetDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.TerminalDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.TokenAST;
import fr.umlv.tatoo.cc.ebnf.ast.TreeAST;
import fr.umlv.tatoo.cc.ebnf.ast.TypeVarAST;
import fr.umlv.tatoo.cc.ebnf.ast.UnquotedIdVarAST;
import fr.umlv.tatoo.cc.ebnf.ast.VariableTypeDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.VariableVarAST;
import fr.umlv.tatoo.cc.ebnf.ast.VersionDefAST;
import fr.umlv.tatoo.cc.ebnf.ast.VersionVarAST;
import java.util.List;
import fr.umlv.tatoo.cc.lexer.ebnf.lexer.RuleEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.TerminalEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.tools.TerminalEvaluator;
import fr.umlv.tatoo.cc.lexer.ebnf.tools.GrammarEvaluator;

import fr.umlv.tatoo.runtime.buffer.LexerBuffer;
import fr.umlv.tatoo.runtime.lexer.LexerListener;
import fr.umlv.tatoo.runtime.parser.SimpleParser;
import fr.umlv.tatoo.runtime.parser.SmartStepReturn;
import fr.umlv.tatoo.runtime.tools.DataViewer;
import fr.umlv.tatoo.runtime.tools.GenericStack;
import fr.umlv.tatoo.runtime.tools.AbstractToolsProcessor;

/**  This class is called by the parser when
 *   <ol>
 *    <li>a terminal is shifted
 *    <li>a non terminal is reduced
 *    <li>a non terminal is accepted
 *   </ol>
 *   In that case, depending on the information of the .xtls, terminal and non-terminal
 *   values are pushed or pop from a semantic stack.
 *   
 *   Furthermore, in case of error recovery, values of the stack can be pop out
 *   depending if the last recognized element is a terminal or a non-terminal.
 * 
 *  This class is generated - please do not edit it 
 */
public class ToolsProcessor<B extends LexerBuffer,D>
  extends AbstractToolsProcessor<B,RuleEnum,TerminalEnum,NonTerminalEnum,ProductionEnum> {
 
  B buffer;
    
                                     
  private final GrammarEvaluator grammarEvaluator;
  private final TerminalEvaluator<? super D> terminalEvaluator;
  private final DataViewer<? super B,? extends D> dataViewer;
  private final GenericStack stack;

  /** Creates a tools processor.
      This constructor allows to share the same stack between more
      than one parser processor.
      @param terminalEvaluator the terminal evaluator.
      @param grammarEvaluator the grammar evaluator.
      @param stack the stack used by the processor
   */
  private ToolsProcessor(TerminalEvaluator<? super D> terminalEvaluator, GrammarEvaluator grammarEvaluator, DataViewer<? super B,? extends D> dataViewer, GenericStack stack) {
    this.terminalEvaluator=terminalEvaluator;
    this.grammarEvaluator=grammarEvaluator;
    this.dataViewer=dataViewer;
    this.stack=stack;
  }
  
  public static <B extends LexerBuffer,D> AbstractToolsProcessor<B,RuleEnum,TerminalEnum,NonTerminalEnum,ProductionEnum>
    createToolsProcessor(TerminalEvaluator<? super D> terminalEvaluator, GrammarEvaluator grammarEvaluator, DataViewer<? super B,? extends D> dataViewer, GenericStack stack) {
    
    return new ToolsProcessor<B,D>(terminalEvaluator,grammarEvaluator,dataViewer,stack);
  }
  
  /** Creates a lexer listener that forwards recognized rule to the parser.
   * @param parser a parser
   * @return a lexer listener.
   */
  @Override
  public LexerListener<RuleEnum,B> createLexerListener(SimpleParser<? super TerminalEnum> parser) {
    return new LexerAdapter(parser);
  }
  
  protected class LexerAdapter implements LexerListener<RuleEnum,B> {
    private final SimpleParser<? super TerminalEnum> parser;
    
    protected LexerAdapter(SimpleParser<? super TerminalEnum> parser) {
      this.parser=parser;
    }
    
    
    /**
     * {@inheritDoc}
     */
    public final void ruleVerified(RuleEnum rule, int lastTokenLength,B buffer)  {   
    ToolsProcessor.this.buffer=buffer; 
    try {
      switch(rule) {
        case space:
              buffer.discard();
             return;
        case directivesdecl:
                 if (parser.smartStep(TerminalEnum.directivesdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case importsdecl:
                 if (parser.smartStep(TerminalEnum.importsdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case prioritiesdecl:
                 if (parser.smartStep(TerminalEnum.prioritiesdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case tokensdecl:
                 if (parser.smartStep(TerminalEnum.tokensdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case blanksdecl:
                 if (parser.smartStep(TerminalEnum.blanksdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case branchesdecl:
                 if (parser.smartStep(TerminalEnum.branchesdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case errordecl:
                 if (parser.smartStep(TerminalEnum.errordecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case typesdecl:
                 if (parser.smartStep(TerminalEnum.typesdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case startsdecl:
                 if (parser.smartStep(TerminalEnum.startsdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case versionsdecl:
                 if (parser.smartStep(TerminalEnum.versionsdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case productionsdecl:
                 if (parser.smartStep(TerminalEnum.productionsdecl)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case eof:
                 if (parser.smartStep(TerminalEnum.eof)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case lbracket:
                 if (parser.smartStep(TerminalEnum.lbracket)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case rbracket:
                 if (parser.smartStep(TerminalEnum.rbracket)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case lsqbracket:
                 if (parser.smartStep(TerminalEnum.lsqbracket)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case rsqbracket:
                 if (parser.smartStep(TerminalEnum.rsqbracket)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case lpar:
                 if (parser.smartStep(TerminalEnum.lpar)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case rpar:
                 if (parser.smartStep(TerminalEnum.rpar)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case assign:
                 if (parser.smartStep(TerminalEnum.assign)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case pipe:
                 if (parser.smartStep(TerminalEnum.pipe)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case dollar:
                 if (parser.smartStep(TerminalEnum.dollar)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case star:
                 if (parser.smartStep(TerminalEnum.star)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case plus:
                 if (parser.smartStep(TerminalEnum.plus)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case slash:
                 if (parser.smartStep(TerminalEnum.slash)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case qmark:
                 if (parser.smartStep(TerminalEnum.qmark)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case quote:
                 if (parser.smartStep(TerminalEnum.quote)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case doublequote:
                 if (parser.smartStep(TerminalEnum.doublequote)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case semicolon:
                 if (parser.smartStep(TerminalEnum.semicolon)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case colon:
                 if (parser.smartStep(TerminalEnum.colon)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case quoted_name:
                 if (parser.smartStep(TerminalEnum.quoted_name)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case assoc:
                 if (parser.smartStep(TerminalEnum.assoc)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case number:
                 if (parser.smartStep(TerminalEnum.number)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case id:
                 if (parser.smartStep(TerminalEnum.id)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case qualifiedid:
                 if (parser.smartStep(TerminalEnum.qualifiedid)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case regexquote:
                 if (parser.smartStep(TerminalEnum.regexquote)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        case regexdoublequote:
                 if (parser.smartStep(TerminalEnum.regexdoublequote)==SmartStepReturn.RELEX) {
            buffer.restart();
            return;
          }
             return;
        }
        throw new AssertionError("unknown rule "+rule);
      }
      finally {
        ToolsProcessor.this.buffer = null;
      }
    }
  }

  public void shift(TerminalEnum terminal) {
     D data;
     switch(terminal) {
      case directivesdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> directivesdecl= terminalEvaluator.directivesdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(directivesdecl);
         return;
      }
      case importsdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> importsdecl= terminalEvaluator.importsdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(importsdecl);
         return;
      }
      case prioritiesdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> prioritiesdecl= terminalEvaluator.prioritiesdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(prioritiesdecl);
         return;
      }
      case tokensdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> tokensdecl= terminalEvaluator.tokensdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(tokensdecl);
         return;
      }
      case blanksdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> blanksdecl= terminalEvaluator.blanksdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(blanksdecl);
         return;
      }
      case branchesdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> branchesdecl= terminalEvaluator.branchesdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(branchesdecl);
         return;
      }
      case startsdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> startsdecl= terminalEvaluator.startsdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(startsdecl);
         return;
      }
      case errordecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> errordecl= terminalEvaluator.errordecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(errordecl);
         return;
      }
      case typesdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> typesdecl= terminalEvaluator.typesdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(typesdecl);
         return;
      }
      case versionsdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> versionsdecl= terminalEvaluator.versionsdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(versionsdecl);
         return;
      }
      case productionsdecl: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> productionsdecl= terminalEvaluator.productionsdecl(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(productionsdecl);
         return;
      }
      case number: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<Double> number= terminalEvaluator.number(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(number);
         return;
      }
      case id: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<String> id= terminalEvaluator.id(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(id);
         return;
      }
      case qualifiedid: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<String> qualifiedid= terminalEvaluator.qualifiedid(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(qualifiedid);
         return;
      }
      case eof: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> eof= terminalEvaluator.eof(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(eof);
         return;
      }
      case quoted_name: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<String> quoted_name= terminalEvaluator.quoted_name(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(quoted_name);
         return;
      }
      case regexquote: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<String> regexquote= terminalEvaluator.regexquote(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(regexquote);
         return;
      }
      case regexdoublequote: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<String> regexdoublequote= terminalEvaluator.regexdoublequote(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(regexdoublequote);
         return;
      }
      case lbracket: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> lbracket= terminalEvaluator.lbracket(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(lbracket);
         return;
      }
      case rbracket: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> rbracket= terminalEvaluator.rbracket(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(rbracket);
         return;
      }
      case lsqbracket: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> lsqbracket= terminalEvaluator.lsqbracket(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(lsqbracket);
         return;
      }
      case rsqbracket: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> rsqbracket= terminalEvaluator.rsqbracket(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(rsqbracket);
         return;
      }
      case lpar: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> lpar= terminalEvaluator.lpar(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(lpar);
         return;
      }
      case rpar: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> rpar= terminalEvaluator.rpar(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(rpar);
         return;
      }
      case assign: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> assign= terminalEvaluator.assign(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(assign);
         return;
      }
      case dollar: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> dollar= terminalEvaluator.dollar(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(dollar);
         return;
      }
      case pipe: {
                      ToolsProcessor.this.buffer.discard();
               return;
      }
      case slash: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> slash= terminalEvaluator.slash(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(slash);
         return;
      }
      case qmark: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> qmark= terminalEvaluator.qmark(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(qmark);
         return;
      }
      case star: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> star= terminalEvaluator.star(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(star);
         return;
      }
      case plus: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> plus= terminalEvaluator.plus(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(plus);
         return;
      }
      case quote: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> quote= terminalEvaluator.quote(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(quote);
         return;
      }
      case doublequote: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> doublequote= terminalEvaluator.doublequote(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(doublequote);
         return;
      }
      case semicolon: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> semicolon= terminalEvaluator.semicolon(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(semicolon);
         return;
      }
      case colon: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<?> colon= terminalEvaluator.colon(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(colon);
         return;
      }
      case assoc: {
          data=dataViewer.view(ToolsProcessor.this.buffer);
             fr.umlv.tatoo.cc.ebnf.ast.TokenAST<String> assoc= terminalEvaluator.assoc(data);
                 ToolsProcessor.this.buffer.discard();
               stack.push_Object(assoc);
         return;
      }
      case __eof__: {
            return;
      }
    }
    throw new AssertionError("unknown terminal "+terminal);
  }

  @SuppressWarnings("unchecked")
  public void reduce(ProductionEnum production) {
    switch(production) {
      case directives_lhs_optional0_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case directives_lhs_optional0_directives_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case imports_lhs_optional1_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case imports_lhs_optional1_imports_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case priorities_lhs_optional2_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case priorities_lhs_optional2_priorities_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case blank_lhs_optional3_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case blank_lhs_optional3_blank_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case branch_lhs_optional4_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case branch_lhs_optional4_branch_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case error_lhs_optional5_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case error_lhs_optional5_error_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case versions_optional6_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case versions_optional6_versions: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case types_lhs_optional7_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case types_lhs_optional7_types_lhs: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case start_non_terminals_optional8_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case start_non_terminals_optional8_start_non_terminals: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case start_def: {
// ast false
// starType NO_STAR

          SimpleNodeAST<?> production_lhs=(SimpleNodeAST<?>) stack.pop_Object();

          StartNonTerminalSetDefAST start_non_terminals_optional8=(StartNonTerminalSetDefAST) stack.pop_Object();

          SimpleNodeAST<?> types_lhs_optional7=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> versions_optional6=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> error_lhs_optional5=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> branch_lhs_optional4=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> blank_lhs_optional3=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> token_lhs=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> priorities_lhs_optional2=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> imports_lhs_optional1=(SimpleNodeAST<?>) stack.pop_Object();

          SimpleNodeAST<?> directives_lhs_optional0=(SimpleNodeAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.start_def(directives_lhs_optional0, imports_lhs_optional1, priorities_lhs_optional2, token_lhs, blank_lhs_optional3, branch_lhs_optional4, error_lhs_optional5, versions_optional6, types_lhs_optional7, start_non_terminals_optional8, production_lhs));
          return;
      }
      case directive_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.DirectiveDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case directive_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          DirectiveDefAST directive=(DirectiveDefAST) stack.pop_Object();
          List<DirectiveDefAST> directive_list=(List<DirectiveDefAST>) stack.pop_Object();
          directive_list.add(directive);
          stack.push_Object(directive_list);
          return;
      }
      case directives_def: {
// ast false
// starType NO_STAR

          List<DirectiveDefAST> directive_list=(List<DirectiveDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> directivesdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.directives_def(directivesdecl, colon, directive_list));
          return;
      }
      case directive_def: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.directive_def(id));
          return;
      }
      case tokens_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.NodeAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case tokens_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          NodeAST lexem=(NodeAST) stack.pop_Object();
          List<NodeAST> tokens_list=(List<NodeAST>) stack.pop_Object();
          tokens_list.add(lexem);
          stack.push_Object(tokens_list);
          return;
      }
      case token_def: {
// ast false
// starType NO_STAR

          List<NodeAST> tokens_list=(List<NodeAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> tokensdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.token_def(tokensdecl, colon, tokens_list));
          return;
      }
      case decls_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.NonTerminalDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case decls_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          NonTerminalDefAST decl=(NonTerminalDefAST) stack.pop_Object();
          List<NonTerminalDefAST> decls=(List<NonTerminalDefAST>) stack.pop_Object();
          decls.add(decl);
          stack.push_Object(decls);
          return;
      }
      case production_def: {
// ast false
// starType NO_STAR

          List<NonTerminalDefAST> decls=(List<NonTerminalDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> productionsdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.production_def(productionsdecl, colon, decls));
          return;
      }
      case blanks_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.NodeAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case blanks_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          NodeAST blank_lexem=(NodeAST) stack.pop_Object();
          List<NodeAST> blanks_list=(List<NodeAST>) stack.pop_Object();
          blanks_list.add(blank_lexem);
          stack.push_Object(blanks_list);
          return;
      }
      case blank_def: {
// ast false
// starType NO_STAR

          List<NodeAST> blanks_list=(List<NodeAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> blanksdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.blank_def(blanksdecl, colon, blanks_list));
          return;
      }
      case banches_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.TerminalDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case banches_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          TerminalDefAST branch_lexem=(TerminalDefAST) stack.pop_Object();
          List<TerminalDefAST> banches_list=(List<TerminalDefAST>) stack.pop_Object();
          banches_list.add(branch_lexem);
          stack.push_Object(banches_list);
          return;
      }
      case branch_def: {
// ast false
// starType NO_STAR

          List<TerminalDefAST> banches_list=(List<TerminalDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> branchesdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.branch_def(branchesdecl, colon, banches_list));
          return;
      }
      case import_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.ImportDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case import_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          ImportDefAST import_=(ImportDefAST) stack.pop_Object();
          List<ImportDefAST> import_list=(List<ImportDefAST>) stack.pop_Object();
          import_list.add(import_);
          stack.push_Object(import_list);
          return;
      }
      case imports_def: {
// ast false
// starType NO_STAR

          List<ImportDefAST> import_list=(List<ImportDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> importsdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.imports_def(importsdecl, colon, import_list));
          return;
      }
      case import_def: {
// ast false
// starType NO_STAR

          TokenAST<String> qualifiedid=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.import_def(qualifiedid));
          return;
      }
      case priority_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.PriorityDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case priority_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          PriorityDefAST priority=(PriorityDefAST) stack.pop_Object();
          List<PriorityDefAST> priority_list=(List<PriorityDefAST>) stack.pop_Object();
          priority_list.add(priority);
          stack.push_Object(priority_list);
          return;
      }
      case priorities_def: {
// ast false
// starType NO_STAR

          List<PriorityDefAST> priority_list=(List<PriorityDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> prioritiesdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.priorities_def(prioritiesdecl, colon, priority_list));
          return;
      }
      case priority_def: {
// ast false
// starType NO_STAR

          TokenAST<String> assoc=(TokenAST<String>) stack.pop_Object();

          TokenAST<Double> number=(TokenAST<Double>) stack.pop_Object();

          TokenAST<?> assign=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.priority_def(id, assign, number, assoc));
          return;
      }
      case version_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.VersionDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case version_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          VersionDefAST version=(VersionDefAST) stack.pop_Object();
          List<VersionDefAST> version_list=(List<VersionDefAST>) stack.pop_Object();
          version_list.add(version);
          stack.push_Object(version_list);
          return;
      }
      case versions_def: {
// ast false
// starType NO_STAR

          List<VersionDefAST> version_list=(List<VersionDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> versionsdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.versions_def(versionsdecl, colon, version_list));
          return;
      }
      case parent_version_optional9_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case parent_version_optional9_parent_version: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case version_def: {
// ast false
// starType NO_STAR

          VersionVarAST parent_version_optional9=(VersionVarAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.version_def(id, parent_version_optional9));
          return;
      }
      case vartypedef_list_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.VariableTypeDefAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case vartypedef_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          VariableTypeDefAST vartypedef=(VariableTypeDefAST) stack.pop_Object();
          List<VariableTypeDefAST> vartypedef_list=(List<VariableTypeDefAST>) stack.pop_Object();
          vartypedef_list.add(vartypedef);
          stack.push_Object(vartypedef_list);
          return;
      }
      case types_def: {
// ast false
// starType NO_STAR

          List<VariableTypeDefAST> vartypedef_list=(List<VariableTypeDefAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> typesdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.types_def(typesdecl, colon, vartypedef_list));
          return;
      }
      case vartype_def: {
// ast false
// starType NO_STAR

          TypeVarAST type=(TypeVarAST) stack.pop_Object();

          VariableVarAST variable=(VariableVarAST) stack.pop_Object();
          stack.push_Object(grammarEvaluator.vartype_def(variable, type));
          return;
      }
      case variable_terminal: {
// ast false
// starType NO_STAR

          TokenAST<?> quote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> quote=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.variable_terminal(quote, id, quote2));
          return;
      }
      case variable_nonterminal: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.variable_nonterminal(id));
          return;
      }
      case parent_version_def: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.parent_version_def(colon, id));
          return;
      }
      case lexem_macro: {
// ast false
// starType NO_STAR

          SimpleNodeAST<String> regex=(SimpleNodeAST<String>) stack.pop_Object();

          TokenAST<?> assign=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> dollar=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.lexem_macro(dollar, id, assign, regex));
          return;
      }
      case alias_optional10_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case alias_optional10_alias: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case type_optional11_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case type_optional11_type: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case regex_terminal_decl_optional12_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case regex_terminal_decl_optional12_regex_terminal_decl: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case terminal_or_prod_priority_optional13_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case terminal_or_prod_priority_optional13_terminal_or_prod_priority: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case lexem_terminal: {
// ast false
// starType NO_STAR

          PriorityVarAST terminal_or_prod_priority_optional13=(PriorityVarAST) stack.pop_Object();

          SimpleNodeAST<String> regex_terminal_decl_optional12=(SimpleNodeAST<String>) stack.pop_Object();

          TypeVarAST type_optional11=(TypeVarAST) stack.pop_Object();

          AliasDefAST alias_optional10=(AliasDefAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.lexem_terminal(id, alias_optional10, type_optional11, regex_terminal_decl_optional12, terminal_or_prod_priority_optional13));
          return;
      }
      case alias_def: {
// ast false
// starType NO_STAR

          TokenAST<?> rpar=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> quoted_name=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> lpar=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.alias_def(lpar, quoted_name, rpar));
          return;
      }
      case regex_terminal_decl: {
// ast false
// starType NO_STAR

          SimpleNodeAST<String> regex=(SimpleNodeAST<String>) stack.pop_Object();

          TokenAST<?> assign=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regex_terminal_decl(assign, regex));
          return;
      }
      case blank_lexem_macro: {
// ast false
// starType NO_STAR

          SimpleNodeAST<String> regex=(SimpleNodeAST<String>) stack.pop_Object();

          TokenAST<?> assign=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> dollar=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.blank_lexem_macro(dollar, id, assign, regex));
          return;
      }
      case blank_lexem_terminal: {
// ast false
// starType NO_STAR

          SimpleNodeAST<String> regex=(SimpleNodeAST<String>) stack.pop_Object();

          TokenAST<?> assign=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.blank_lexem_terminal(id, assign, regex));
          return;
      }
      case regex_quote: {
// ast false
// starType NO_STAR

          TokenAST<?> quote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> regexquote=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> quote=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regex_quote(quote, regexquote, quote2));
          return;
      }
      case regex_doublequote: {
// ast false
// starType NO_STAR

          TokenAST<?> doublequote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> regexdoublequote=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> doublequote=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.regex_doublequote(doublequote, regexdoublequote, doublequote2));
          return;
      }
      case type_optional14_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case type_optional14_type: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case terminal_or_prod_priority_optional15_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case terminal_or_prod_priority_optional15_terminal_or_prod_priority: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case branch_lexem_terminal: {
// ast false
// starType NO_STAR

          PriorityVarAST terminal_or_prod_priority_optional15=(PriorityVarAST) stack.pop_Object();

          TypeVarAST type_optional14=(TypeVarAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.branch_lexem_terminal(id, type_optional14, terminal_or_prod_priority_optional15));
          return;
      }
      case terminal_or_prod_priority_optional16_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case terminal_or_prod_priority_optional16_terminal_or_prod_priority: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case branch_eof_terminal: {
// ast false
// starType NO_STAR

          PriorityVarAST terminal_or_prod_priority_optional16=(PriorityVarAST) stack.pop_Object();

          TokenAST<?> eof=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.branch_eof_terminal(eof, terminal_or_prod_priority_optional16));
          return;
      }
      case terminal_or_prod_priority: {
// ast false
// starType NO_STAR

          TokenAST<?> rsqbracket=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> lsqbracket=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.terminal_or_prod_priority(lsqbracket, id, rsqbracket));
          return;
      }
      case type_def: {
// ast false
// starType NO_STAR

          TokenAST<String> qualifiedid=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.type_def(colon, qualifiedid));
          return;
      }
      case starts_list_element: {
// ast false
// starType STAR_SINGLETON
          // star singleton
          java.util.ArrayList<UnquotedIdVarAST> list=new java.util.ArrayList<UnquotedIdVarAST>();

          list.add((UnquotedIdVarAST) stack.pop_Object());
          stack.push_Object(list);
          return;
      }
      case starts_list_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          UnquotedIdVarAST startid=(UnquotedIdVarAST) stack.pop_Object();
          List<UnquotedIdVarAST> starts_list=(List<UnquotedIdVarAST>) stack.pop_Object();
          starts_list.add(startid);
          stack.push_Object(starts_list);
          return;
      }
      case start_non_terminals_def: {
// ast false
// starType NO_STAR

          List<UnquotedIdVarAST> starts_list=(List<UnquotedIdVarAST>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> startsdecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.start_non_terminals_def(startsdecl, colon, starts_list));
          return;
      }
      case startid_def: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.startid_def(id));
          return;
      }
      case error_def: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> errordecl=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.error_def(errordecl, colon, id));
          return;
      }
      case type_optional17_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case type_optional17_type: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case prods_element: {
// ast false
// starType STAR_SINGLETON
          // star singleton
          java.util.ArrayList<TreeAST> list=new java.util.ArrayList<TreeAST>();

          list.add((TreeAST) stack.pop_Object());
          stack.push_Object(list);
          return;
      }
      case prods_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          TreeAST prod=(TreeAST) stack.pop_Object();
          List<TreeAST> prods=(List<TreeAST>) stack.pop_Object();
          prods.add(prod);
          stack.push_Object(prods);
          return;
      }
      case decl_productions: {
// ast false
// starType NO_STAR

          TokenAST<?> semicolon=(TokenAST<?>) stack.pop_Object();

          List<TreeAST> prods=(List<TreeAST>) stack.pop_Object();

          TokenAST<?> assign=(TokenAST<?>) stack.pop_Object();

          TypeVarAST type_optional17=(TypeVarAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.decl_productions(id, type_optional17, assign, prods, semicolon));
          return;
      }
      case varlist_empty: {
// ast false
// starType STAR_EMPTY
          // star empty java.util.List<fr.umlv.tatoo.cc.ebnf.ast.NodeAST>
          stack.push_Object(new java.util.ArrayList<Object>());
          return;
      }
      case varlist_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          NodeAST var=(NodeAST) stack.pop_Object();
          List<NodeAST> varlist=(List<NodeAST>) stack.pop_Object();
          varlist.add(var);
          stack.push_Object(varlist);
          return;
      }
      case terminal_or_prod_priority_optional18_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case terminal_or_prod_priority_optional18_terminal_or_prod_priority: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case production_id_optional19_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case production_id_optional19_production_id: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case prod_production: {
// ast false
// starType NO_STAR

          ProductionIdAndVersionDefAST production_id_optional19=(ProductionIdAndVersionDefAST) stack.pop_Object();

          PriorityVarAST terminal_or_prod_priority_optional18=(PriorityVarAST) stack.pop_Object();

          List<NodeAST> varlist=(List<NodeAST>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.prod_production(varlist, terminal_or_prod_priority_optional18, production_id_optional19));
          return;
      }
      case production_version_optional20_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case production_version_optional20_production_version: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case production_id: {
// ast false
// starType NO_STAR

          TokenAST<?> rbracket=(TokenAST<?>) stack.pop_Object();

          VersionVarAST production_version_optional20=(VersionVarAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> lbracket=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.production_id(lbracket, id, production_version_optional20, rbracket));
          return;
      }
      case production_version: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> colon=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.production_version(colon, id));
          return;
      }
      case vargroup_element: {
// ast false
// starType STAR_SINGLETON
          // star singleton
          java.util.ArrayList<NodeAST> list=new java.util.ArrayList<NodeAST>();

          list.add((NodeAST) stack.pop_Object());
          stack.push_Object(list);
          return;
      }
      case vargroup_rec: {
// ast false
// starType STAR_RECURSIVE_LEFT
          // star recursive left
          NodeAST var=(NodeAST) stack.pop_Object();
          List<NodeAST> vargroup=(List<NodeAST>) stack.pop_Object();
          vargroup.add(var);
          stack.push_Object(vargroup);
          return;
      }
      case var_group: {
// ast false
// starType NO_STAR

          TokenAST<?> rpar=(TokenAST<?>) stack.pop_Object();

          List<NodeAST> vargroup=(List<NodeAST>) stack.pop_Object();

          TokenAST<?> lpar=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_group(lpar, vargroup, rpar));
          return;
      }
      case qmark_optional21_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case qmark_optional21_qmark: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case var_terminal: {
// ast false
// starType NO_STAR

          TokenAST<?> qmark_optional21=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> quote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> quote=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_terminal(quote, id, quote2, qmark_optional21));
          return;
      }
      case qmark_optional22_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case qmark_optional22_qmark: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case var_nonterminal: {
// ast false
// starType NO_STAR

          TokenAST<?> qmark_optional22=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_nonterminal(id, qmark_optional22));
          return;
      }
      case separator_optional23_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case separator_optional23_separator: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case var_terminal_star: {
// ast false
// starType NO_STAR

          TokenAST<?> star=(TokenAST<?>) stack.pop_Object();

          VariableVarAST separator_optional23=(VariableVarAST) stack.pop_Object();

          TokenAST<?> quote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> quote=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_terminal_star(quote, id, quote2, separator_optional23, star));
          return;
      }
      case separator_optional24_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case separator_optional24_separator: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case var_terminal_plus: {
// ast false
// starType NO_STAR

          TokenAST<?> plus=(TokenAST<?>) stack.pop_Object();

          VariableVarAST separator_optional24=(VariableVarAST) stack.pop_Object();

          TokenAST<?> quote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> quote=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_terminal_plus(quote, id, quote2, separator_optional24, plus));
          return;
      }
      case separator_optional25_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case separator_optional25_separator: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case var_nonterminal_star: {
// ast false
// starType NO_STAR

          TokenAST<?> star=(TokenAST<?>) stack.pop_Object();

          VariableVarAST separator_optional25=(VariableVarAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_nonterminal_star(id, separator_optional25, star));
          return;
      }
      case separator_optional26_empty: {
// ast false
// starType OPTIONAL_EMPTY
          // optional empty
          stack.push_Object(null);
          return;
      }
      case separator_optional26_separator: {
// ast false
// starType OPTIONAL_SINGLETON
          // optional singleton    
          return;
      }
      case var_nonterminal_plus: {
// ast false
// starType NO_STAR

          TokenAST<?> plus=(TokenAST<?>) stack.pop_Object();

          VariableVarAST separator_optional26=(VariableVarAST) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.var_nonterminal_plus(id, separator_optional26, plus));
          return;
      }
      case separator_terminal: {
// ast false
// starType NO_STAR

          TokenAST<?> quote2=(TokenAST<?>) stack.pop_Object();

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> quote=(TokenAST<?>) stack.pop_Object();

          TokenAST<?> slash=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.separator_terminal(slash, quote, id, quote2));
          return;
      }
      case separator_non_terminal: {
// ast false
// starType NO_STAR

          TokenAST<String> id=(TokenAST<String>) stack.pop_Object();

          TokenAST<?> slash=(TokenAST<?>) stack.pop_Object();
          stack.push_Object(grammarEvaluator.separator_non_terminal(slash, id));
          return;
      }
    }
    throw new AssertionError("unknown production "+production);
  }

  @SuppressWarnings("unchecked")
  public void accept(NonTerminalEnum nonterminal) {
    switch(nonterminal) {
      case start:
        grammarEvaluator.acceptStart((RootDefAST) stack.pop_Object());

        return;
      default:
    }
    throw new AssertionError("unknown start nonterminal "+nonterminal);
  }

  public void popTerminalOnError(TerminalEnum terminal) {
    switch(terminal) {
      case directivesdecl:
        stack.pop_Object();
        return;
      case importsdecl:
        stack.pop_Object();
        return;
      case prioritiesdecl:
        stack.pop_Object();
        return;
      case tokensdecl:
        stack.pop_Object();
        return;
      case blanksdecl:
        stack.pop_Object();
        return;
      case branchesdecl:
        stack.pop_Object();
        return;
      case startsdecl:
        stack.pop_Object();
        return;
      case errordecl:
        stack.pop_Object();
        return;
      case typesdecl:
        stack.pop_Object();
        return;
      case versionsdecl:
        stack.pop_Object();
        return;
      case productionsdecl:
        stack.pop_Object();
        return;
      case number:
        stack.pop_Object();
        return;
      case id:
        stack.pop_Object();
        return;
      case qualifiedid:
        stack.pop_Object();
        return;
      case eof:
        stack.pop_Object();
        return;
      case quoted_name:
        stack.pop_Object();
        return;
      case regexquote:
        stack.pop_Object();
        return;
      case regexdoublequote:
        stack.pop_Object();
        return;
      case lbracket:
        stack.pop_Object();
        return;
      case rbracket:
        stack.pop_Object();
        return;
      case lsqbracket:
        stack.pop_Object();
        return;
      case rsqbracket:
        stack.pop_Object();
        return;
      case lpar:
        stack.pop_Object();
        return;
      case rpar:
        stack.pop_Object();
        return;
      case assign:
        stack.pop_Object();
        return;
      case dollar:
        stack.pop_Object();
        return;
      case pipe:
        return;
      case slash:
        stack.pop_Object();
        return;
      case qmark:
        stack.pop_Object();
        return;
      case star:
        stack.pop_Object();
        return;
      case plus:
        stack.pop_Object();
        return;
      case quote:
        stack.pop_Object();
        return;
      case doublequote:
        stack.pop_Object();
        return;
      case semicolon:
        stack.pop_Object();
        return;
      case colon:
        stack.pop_Object();
        return;
      case assoc:
        stack.pop_Object();
        return;
      case __eof__:
        return;
    }
    throw new AssertionError("unknown terminal "+terminal);
  }

  public void popNonTerminalOnError(NonTerminalEnum nonterminal) {
    switch(nonterminal) {
      case start:
        stack.pop_Object();
        return;
      case directives_lhs:
        stack.pop_Object();
        return;
      case directives_lhs_optional0:
        stack.pop_Object();
        return;
      case imports_lhs:
        stack.pop_Object();
        return;
      case imports_lhs_optional1:
        stack.pop_Object();
        return;
      case priorities_lhs:
        stack.pop_Object();
        return;
      case priorities_lhs_optional2:
        stack.pop_Object();
        return;
      case token_lhs:
        stack.pop_Object();
        return;
      case blank_lhs:
        stack.pop_Object();
        return;
      case blank_lhs_optional3:
        stack.pop_Object();
        return;
      case branch_lhs:
        stack.pop_Object();
        return;
      case branch_lhs_optional4:
        stack.pop_Object();
        return;
      case error_lhs:
        stack.pop_Object();
        return;
      case error_lhs_optional5:
        stack.pop_Object();
        return;
      case versions:
        stack.pop_Object();
        return;
      case versions_optional6:
        stack.pop_Object();
        return;
      case types_lhs:
        stack.pop_Object();
        return;
      case types_lhs_optional7:
        stack.pop_Object();
        return;
      case start_non_terminals:
        stack.pop_Object();
        return;
      case start_non_terminals_optional8:
        stack.pop_Object();
        return;
      case production_lhs:
        stack.pop_Object();
        return;
      case directive:
        stack.pop_Object();
        return;
      case directive_list:
        stack.pop_Object();
        return;
      case lexem:
        stack.pop_Object();
        return;
      case tokens_list:
        stack.pop_Object();
        return;
      case decl:
        stack.pop_Object();
        return;
      case decls:
        stack.pop_Object();
        return;
      case blank_lexem:
        stack.pop_Object();
        return;
      case blanks_list:
        stack.pop_Object();
        return;
      case branch_lexem:
        stack.pop_Object();
        return;
      case banches_list:
        stack.pop_Object();
        return;
      case import_:
        stack.pop_Object();
        return;
      case import_list:
        stack.pop_Object();
        return;
      case priority:
        stack.pop_Object();
        return;
      case priority_list:
        stack.pop_Object();
        return;
      case version:
        stack.pop_Object();
        return;
      case version_list:
        stack.pop_Object();
        return;
      case parent_version:
        stack.pop_Object();
        return;
      case parent_version_optional9:
        stack.pop_Object();
        return;
      case vartypedef:
        stack.pop_Object();
        return;
      case vartypedef_list:
        stack.pop_Object();
        return;
      case variable:
        stack.pop_Object();
        return;
      case type:
        stack.pop_Object();
        return;
      case regex:
        stack.pop_Object();
        return;
      case alias:
        stack.pop_Object();
        return;
      case alias_optional10:
        stack.pop_Object();
        return;
      case type_optional11:
        stack.pop_Object();
        return;
      case regex_terminal_decl:
        stack.pop_Object();
        return;
      case regex_terminal_decl_optional12:
        stack.pop_Object();
        return;
      case terminal_or_prod_priority:
        stack.pop_Object();
        return;
      case terminal_or_prod_priority_optional13:
        stack.pop_Object();
        return;
      case type_optional14:
        stack.pop_Object();
        return;
      case terminal_or_prod_priority_optional15:
        stack.pop_Object();
        return;
      case terminal_or_prod_priority_optional16:
        stack.pop_Object();
        return;
      case startid:
        stack.pop_Object();
        return;
      case starts_list:
        stack.pop_Object();
        return;
      case type_optional17:
        stack.pop_Object();
        return;
      case prod:
        stack.pop_Object();
        return;
      case prods:
        stack.pop_Object();
        return;
      case var:
        stack.pop_Object();
        return;
      case varlist:
        stack.pop_Object();
        return;
      case terminal_or_prod_priority_optional18:
        stack.pop_Object();
        return;
      case production_id:
        stack.pop_Object();
        return;
      case production_id_optional19:
        stack.pop_Object();
        return;
      case production_version:
        stack.pop_Object();
        return;
      case production_version_optional20:
        stack.pop_Object();
        return;
      case vargroup:
        stack.pop_Object();
        return;
      case qmark_optional21:
        stack.pop_Object();
        return;
      case qmark_optional22:
        stack.pop_Object();
        return;
      case separator:
        stack.pop_Object();
        return;
      case separator_optional23:
        stack.pop_Object();
        return;
      case separator_optional24:
        stack.pop_Object();
        return;
      case separator_optional25:
        stack.pop_Object();
        return;
      case separator_optional26:
        stack.pop_Object();
        return;
    }
    throw new AssertionError("unknown nonterminal "+nonterminal);
  }
}
