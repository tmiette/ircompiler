package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.TerminalEnum;
import fr.umlv.tatoo.runtime.parser.AcceptAction;
import fr.umlv.tatoo.runtime.parser.Action;
import fr.umlv.tatoo.runtime.parser.BranchAction;
import fr.umlv.tatoo.runtime.parser.ErrorAction;
import fr.umlv.tatoo.runtime.parser.ExitAction;
import fr.umlv.tatoo.runtime.parser.ParserTable;
import fr.umlv.tatoo.runtime.parser.ReduceAction;
import fr.umlv.tatoo.runtime.parser.ShiftAction;
import fr.umlv.tatoo.runtime.parser.StateMetadata;
import java.util.EnumMap;

/** 
 *  This class is generated - please do not edit it 
 */
public class ParserDataTable {
  @SuppressWarnings("unchecked")
  private ParserDataTable() {
    accept = AcceptAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    exit = ExitAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    initmainGotoes();
    initspecialOrStringLetterGotoes();
    initspecialOrNormalLetterGotoes();
    initregexGotoes();
    initmacroGotoes();
    initstringGotoes();
    inithatOptGotoes();
    initintervalGotoes();
    initspecialOrIntervalLetterGotoes();
    initpatternGotoes();
    initintervalsGotoes();
    initfollowGotoes();
    reduceregexMacro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexMacro,1,regexGotoes);
    reducestringSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.stringSpecialLetter,1,specialOrStringLetterGotoes);
    reduceintervalSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSpecialLetter,1,specialOrIntervalLetterGotoes);
    reducestring = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.string,2,stringGotoes);
    reducenormalSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.normalSpecialLetter,1,specialOrNormalLetterGotoes);
    reducefollowEmpty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followEmpty,0,followGotoes);
    reduceintervalSingleton = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSingleton,1,intervalGotoes);
    reducenormalLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.normalLetter,1,specialOrNormalLetterGotoes);
    reducestringLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.stringLetter,1,specialOrStringLetterGotoes);
    reducemainRegex = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.mainRegex,1,mainGotoes);
    reduceregexCat = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexCat,2,regexGotoes);
    reducehatPresent = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.hatPresent,1,hatOptGotoes);
    reducehatEmpty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.hatEmpty,0,hatOptGotoes);
    reducespecialOrStringLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.specialOrStringLetter,1,stringGotoes);
    reduceregexAny = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexAny,1,regexGotoes);
    reduceregexRange = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexRange,6,regexGotoes);
    reduceintervalLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalLetter,1,specialOrIntervalLetterGotoes);
    reduceregexPlus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexPlus,2,regexGotoes);
    reduceinitial = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.initial,3,patternGotoes);
    reducemacro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.macro,1,macroGotoes);
    reducefollowRegex = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followRegex,2,followGotoes);
    reduceintervals = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervals,2,intervalsGotoes);
    reduceregexTimes = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexTimes,4,regexGotoes);
    reduceregexOptional = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexOptional,2,regexGotoes);
    reduceregexPar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexPar,3,regexGotoes);
    reduceregexIntervalNegate = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexIntervalNegate,4,regexGotoes);
    reduceregexAtLeast = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexAtLeast,5,regexGotoes);
    reduceintervalSet = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSet,3,intervalGotoes);
    reduceregexString = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexString,3,regexGotoes);
    reduceregexStar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexStar,2,regexGotoes);
    reduceregexInterval = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexInterval,3,regexGotoes);
    reduceregexOr = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexOr,3,regexGotoes);
    reduceinterval = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.interval,1,intervalsGotoes);
    reducefollowDollar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followDollar,1,followGotoes);
    reduceregexLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexLetter,1,regexGotoes);
    shift34 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(34);
    shift32 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(32);
    shift13 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(13);
    shift31 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(31);
    shift49 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(49);
    shift46 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(46);
    shift16 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(16);
    shift50 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(50);
    shift19 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(19);
    shift3 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(3);
    shift35 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(35);
    shift36 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(36);
    shift24 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(24);
    shift8 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(8);
    shift39 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(39);
    shift1 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(1);
    shift28 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(28);
    shift40 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(40);
    shift30 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(30);
    shift33 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(33);
    shift11 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(11);
    shift29 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(29);
    shift6 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(6);
    shift25 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(25);
    shift22 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(22);
    shift2 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(2);
    shift9 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(9);
    shift38 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(38);
    shift12 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(12);
    shift10 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(10);
    shift23 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(23);
    error0 = new ErrorAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    branch0 = new BranchAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    initquoteArray();
    initstringLetterArray();
    initlbracArray();
    initnormalLetterArray();
    initdollarArray();
    initrparArray();
    initpipeArray();
    initrbrakArray();
    initnameArray();
    initspecialLetterArray();
    initquestionArray();
    initcommaArray();
    initintegerArray();
    initminusArray();
    initintervalLetterArray();
    initplusArray();
    initstarArray();
    initrbracArray();
    init__eof__Array();
    initlparArray();
    inithatArray();
    initlbrakArray();
    initslashArray();
    initdotArray();
    EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]> tableMap =
      new EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]>(TerminalEnum.class);

    tableMap.put(TerminalEnum.quote,quoteArray);
    tableMap.put(TerminalEnum.stringLetter,stringLetterArray);
    tableMap.put(TerminalEnum.lbrac,lbracArray);
    tableMap.put(TerminalEnum.normalLetter,normalLetterArray);
    tableMap.put(TerminalEnum.dollar,dollarArray);
    tableMap.put(TerminalEnum.rpar,rparArray);
    tableMap.put(TerminalEnum.pipe,pipeArray);
    tableMap.put(TerminalEnum.rbrak,rbrakArray);
    tableMap.put(TerminalEnum.name,nameArray);
    tableMap.put(TerminalEnum.specialLetter,specialLetterArray);
    tableMap.put(TerminalEnum.question,questionArray);
    tableMap.put(TerminalEnum.comma,commaArray);
    tableMap.put(TerminalEnum.integer,integerArray);
    tableMap.put(TerminalEnum.minus,minusArray);
    tableMap.put(TerminalEnum.intervalLetter,intervalLetterArray);
    tableMap.put(TerminalEnum.plus,plusArray);
    tableMap.put(TerminalEnum.star,starArray);
    tableMap.put(TerminalEnum.rbrac,rbracArray);
    tableMap.put(TerminalEnum.__eof__,__eof__Array);
    tableMap.put(TerminalEnum.lpar,lparArray);
    tableMap.put(TerminalEnum.hat,hatArray);
    tableMap.put(TerminalEnum.lbrak,lbrakArray);
    tableMap.put(TerminalEnum.slash,slashArray);
    tableMap.put(TerminalEnum.dot,dotArray);

    initBranchArrayTable();

    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0slash = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.slash);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0intervals = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.intervals);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0rbrak = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrak);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0dollar = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dollar);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0regex = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0string = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.string);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0intervalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.intervalLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0normalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.normalLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0integer = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.integer);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0interval = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.interval);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0stringLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.stringLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0specialOrNormalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrNormalLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0plus = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.plus);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0specialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0__eof__ = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.__eof__);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lbrac = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbrac);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(null);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0hatOpt = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.hatOpt);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lpar = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lpar);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0minus = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.minus);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0rbrac = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0dot = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dot);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0pattern = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.pattern);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0star = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.star);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0specialOrIntervalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrIntervalLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0specialOrStringLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrStringLetter);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0question = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.question);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0hat = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.hat);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0comma = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.comma);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0quote = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0follow = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.follow);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0name = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.name);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0pipe = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.pipe);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0macro = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.macro);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0rpar = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rpar);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0lbrak = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbrak);
    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum> metadata0main = StateMetadata.<TerminalEnum,NonTerminalEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.main);

    StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum>[] tableMetadata = (StateMetadata<TerminalEnum,NonTerminalEnum,VersionEnum>[])new StateMetadata<?,?,?>[]{metadata0null, metadata0quote, metadata0stringLetter, metadata0specialLetter, metadata0specialOrStringLetter, metadata0string, metadata0quote, metadata0specialOrStringLetter, metadata0normalLetter, metadata0lpar, metadata0lbrak, metadata0hat, metadata0specialLetter, metadata0intervalLetter, metadata0interval, metadata0specialOrIntervalLetter, metadata0minus, metadata0specialOrIntervalLetter, metadata0intervals, metadata0rbrak, metadata0interval, metadata0intervals, metadata0rbrak, metadata0name, metadata0specialLetter, metadata0dot, metadata0specialOrNormalLetter, metadata0regex, metadata0lbrac, metadata0integer, metadata0rbrac, metadata0comma, metadata0rbrac, metadata0integer, metadata0rbrac, metadata0rpar, metadata0pipe, metadata0regex, metadata0plus, metadata0star, metadata0question, metadata0regex, metadata0regex, metadata0macro, metadata0__eof__, metadata0null, metadata0hat, metadata0hatOpt, metadata0main, metadata0dollar, metadata0slash, metadata0regex, metadata0follow, metadata0regex, metadata0pattern, metadata0__eof__};
    
    EnumMap<NonTerminalEnum,Integer> tableStarts =
      new EnumMap<NonTerminalEnum,Integer>(NonTerminalEnum.class);
    tableStarts.put(NonTerminalEnum.macro,0);
    tableStarts.put(NonTerminalEnum.pattern,45);
    table = new ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>(tableMap,branchArrayTable,tableMetadata,tableStarts,VersionEnum.values(),56,TerminalEnum.__eof__, null);
  } 
  

  private int[] mainGotoes;

  private void initmainGotoes() {
    mainGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 48, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] specialOrStringLetterGotoes;

  private void initspecialOrStringLetterGotoes() {
    specialOrStringLetterGotoes = 
      new int[]{-1, 4, -1, -1, -1, 7, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] specialOrNormalLetterGotoes;

  private void initspecialOrNormalLetterGotoes() {
    specialOrNormalLetterGotoes = 
      new int[]{26, -1, -1, -1, -1, -1, -1, -1, -1, 26, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 26, -1, -1, -1, -1, -1, -1, -1, -1, 26, 26, -1, -1, -1, 26, 26, -1, -1, -1, -1, 26, -1, -1, 26, 26, -1, 26, -1, -1};
  }

  private int[] regexGotoes;

  private void initregexGotoes() {
    regexGotoes = 
      new int[]{42, -1, -1, -1, -1, -1, -1, -1, -1, 27, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 41, -1, -1, -1, -1, -1, -1, -1, -1, 37, 41, -1, -1, -1, 41, 41, -1, -1, -1, -1, 53, -1, -1, 51, 41, -1, 41, -1, -1};
  }

  private int[] macroGotoes;

  private void initmacroGotoes() {
    macroGotoes = 
      new int[]{43, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] stringGotoes;

  private void initstringGotoes() {
    stringGotoes = 
      new int[]{-1, 5, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] hatOptGotoes;

  private void inithatOptGotoes() {
    hatOptGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 47, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] intervalGotoes;

  private void initintervalGotoes() {
    intervalGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 14, 14, -1, -1, -1, -1, -1, -1, 20, -1, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] specialOrIntervalLetterGotoes;

  private void initspecialOrIntervalLetterGotoes() {
    specialOrIntervalLetterGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 15, 15, -1, -1, -1, -1, 17, -1, 15, -1, -1, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] patternGotoes;

  private void initpatternGotoes() {
    patternGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 54, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] intervalsGotoes;

  private void initintervalsGotoes() {
    intervalsGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 21, 18, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
  }

  private int[] followGotoes;

  private void initfollowGotoes() {
    followGotoes = 
      new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 52, -1, -1, -1, -1, -1, -1, -1};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoteArray;
  @SuppressWarnings("unchecked")
  private void initquoteArray() {
    quoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift1, branch0, reducestringLetter, reducestringSpecialLetter, reducespecialOrStringLetter, shift6, reduceregexString, reducestring, reducenormalLetter, shift1, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift1, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift1, shift1, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift1, branch0, branch0, reducehatEmpty, reducehatPresent, shift1, branch0, branch0, shift1, shift1, branch0, shift1, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] stringLetterArray;
  @SuppressWarnings("unchecked")
  private void initstringLetterArray() {
    stringLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, shift2, reducestringLetter, reducestringSpecialLetter, reducespecialOrStringLetter, shift2, branch0, reducestring, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbracArray;
  @SuppressWarnings("unchecked")
  private void initlbracArray() {
    lbracArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift28, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, shift28, reduceregexPlus, reduceregexStar, reduceregexOptional, shift28, shift28, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift28, branch0, shift28, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] normalLetterArray;
  @SuppressWarnings("unchecked")
  private void initnormalLetterArray() {
    normalLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift8, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, shift8, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift8, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift8, shift8, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift8, branch0, branch0, reducehatEmpty, reducehatPresent, shift8, branch0, branch0, shift8, shift8, branch0, shift8, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dollarArray;
  @SuppressWarnings("unchecked")
  private void initdollarArray() {
    dollarArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, branch0, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, reduceregexOr, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, branch0, branch0, branch0, branch0, branch0, branch0, shift49, branch0, branch0, branch0, branch0, reducemainRegex, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rparArray;
  @SuppressWarnings("unchecked")
  private void initrparArray() {
    rparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift35, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, reduceregexOr, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] pipeArray;
  @SuppressWarnings("unchecked")
  private void initpipeArray() {
    pipeArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift36, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, reduceregexOr, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift36, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift36, branch0, shift36, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbrakArray;
  @SuppressWarnings("unchecked")
  private void initrbrakArray() {
    rbrakArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceintervalSpecialLetter, reduceintervalLetter, reduceinterval, reduceintervalSingleton, branch0, reduceintervalSet, shift19, branch0, reduceintervals, shift22, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] nameArray;
  @SuppressWarnings("unchecked")
  private void initnameArray() {
    nameArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift23, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, shift23, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift23, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift23, shift23, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift23, branch0, branch0, reducehatEmpty, reducehatPresent, shift23, branch0, branch0, shift23, shift23, branch0, shift23, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] specialLetterArray;
  @SuppressWarnings("unchecked")
  private void initspecialLetterArray() {
    specialLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift24, shift3, reducestringLetter, reducestringSpecialLetter, reducespecialOrStringLetter, shift3, reduceregexString, reducestring, reducenormalLetter, shift24, shift12, shift12, reduceintervalSpecialLetter, reduceintervalLetter, reduceinterval, reduceintervalSingleton, shift12, reduceintervalSet, shift12, reduceregexIntervalNegate, reduceintervals, shift12, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift24, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift24, shift24, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift24, branch0, branch0, reducehatEmpty, reducehatPresent, shift24, branch0, branch0, shift24, shift24, branch0, shift24, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] questionArray;
  @SuppressWarnings("unchecked")
  private void initquestionArray() {
    questionArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift40, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, shift40, reduceregexPlus, reduceregexStar, reduceregexOptional, shift40, shift40, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift40, branch0, shift40, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] commaArray;
  @SuppressWarnings("unchecked")
  private void initcommaArray() {
    commaArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift31, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] integerArray;
  @SuppressWarnings("unchecked")
  private void initintegerArray() {
    integerArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift29, branch0, branch0, shift33, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] minusArray;
  @SuppressWarnings("unchecked")
  private void initminusArray() {
    minusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceintervalSpecialLetter, reduceintervalLetter, branch0, shift16, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] intervalLetterArray;
  @SuppressWarnings("unchecked")
  private void initintervalLetterArray() {
    intervalLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift13, shift13, reduceintervalSpecialLetter, reduceintervalLetter, reduceinterval, reduceintervalSingleton, shift13, reduceintervalSet, shift13, branch0, reduceintervals, shift13, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] plusArray;
  @SuppressWarnings("unchecked")
  private void initplusArray() {
    plusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift38, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, shift38, reduceregexPlus, reduceregexStar, reduceregexOptional, shift38, shift38, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift38, branch0, shift38, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] starArray;
  @SuppressWarnings("unchecked")
  private void initstarArray() {
    starArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift39, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, shift39, reduceregexPlus, reduceregexStar, reduceregexOptional, shift39, shift39, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift39, branch0, shift39, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbracArray;
  @SuppressWarnings("unchecked")
  private void initrbracArray() {
    rbracArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift30, branch0, shift32, branch0, shift34, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] __eof__Array;
  @SuppressWarnings("unchecked")
  private void init__eof__Array() {
    __eof__Array=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, branch0, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, reduceregexOr, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, reducemacro, accept, accept, branch0, branch0, branch0, reducefollowEmpty, reducefollowDollar, branch0, reducefollowRegex, reduceinitial, reducemainRegex, accept, accept};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lparArray;
  @SuppressWarnings("unchecked")
  private void initlparArray() {
    lparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift9, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, shift9, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift9, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift9, shift9, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift9, branch0, branch0, reducehatEmpty, reducehatPresent, shift9, branch0, branch0, shift9, shift9, branch0, shift9, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] hatArray;
  @SuppressWarnings("unchecked")
  private void inithatArray() {
    hatArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift11, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, shift46, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbrakArray;
  @SuppressWarnings("unchecked")
  private void initlbrakArray() {
    lbrakArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift10, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, shift10, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift10, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift10, shift10, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift10, branch0, branch0, reducehatEmpty, reducehatPresent, shift10, branch0, branch0, shift10, shift10, branch0, shift10, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] slashArray;
  @SuppressWarnings("unchecked")
  private void initslashArray() {
    slashArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, branch0, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, branch0, reduceregexOr, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, branch0, branch0, branch0, branch0, branch0, branch0, shift50, branch0, branch0, branch0, branch0, reducemainRegex, branch0, branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dotArray;
  @SuppressWarnings("unchecked")
  private void initdotArray() {
    dotArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift25, branch0, branch0, branch0, branch0, branch0, reduceregexString, branch0, reducenormalLetter, shift25, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, branch0, reduceregexIntervalNegate, branch0, branch0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, shift25, branch0, branch0, reduceregexTimes, branch0, reduceregexAtLeast, branch0, reduceregexRange, reduceregexPar, shift25, shift25, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, shift25, branch0, branch0, reducehatEmpty, reducehatPresent, shift25, branch0, branch0, shift25, shift25, branch0, shift25, branch0, branch0};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchArrayTable;
  @SuppressWarnings("unchecked")
  private void initBranchArrayTable() {
    branchArrayTable=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{error0, error0, error0, error0, error0, error0, reduceregexString, error0, reducenormalLetter, error0, error0, error0, error0, error0, error0, error0, error0, error0, error0, reduceregexIntervalNegate, error0, error0, reduceregexInterval, reduceregexMacro, reducenormalSpecialLetter, reduceregexAny, reduceregexLetter, error0, error0, error0, reduceregexTimes, error0, reduceregexAtLeast, error0, reduceregexRange, reduceregexPar, error0, reduceregexOr, reduceregexPlus, reduceregexStar, reduceregexOptional, reduceregexCat, reducemacro, exit, exit, error0, error0, error0, reducefollowEmpty, reducefollowDollar, error0, reducefollowRegex, reduceinitial, reducemainRegex, exit, exit};
  }

  private final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> table;
  
  public static final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> createTable() {
    return new ParserDataTable().table;
  }

  private final AcceptAction<TerminalEnum,ProductionEnum,VersionEnum> accept;
  private final ExitAction<TerminalEnum,ProductionEnum,VersionEnum> exit;

  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexMacro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestringSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestring;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducenormalSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowEmpty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSingleton;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducenormalLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestringLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducemainRegex;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexCat;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducehatPresent;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducehatEmpty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducespecialOrStringLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexAny;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexRange;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexPlus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceinitial;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducemacro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowRegex;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervals;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexTimes;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexOptional;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexPar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexIntervalNegate;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexAtLeast;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSet;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexString;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexStar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexInterval;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexOr;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceinterval;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowDollar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexLetter;

  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift34;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift32;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift13;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift31;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift49;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift46;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift16;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift50;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift19;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift3;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift35;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift36;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift24;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift8;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift39;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift1;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift28;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift40;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift30;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift33;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift11;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift29;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift6;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift25;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift22;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift2;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift9;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift38;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift12;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift10;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift23;


  private final ErrorAction<TerminalEnum,ProductionEnum,VersionEnum> error0;

  private final BranchAction<TerminalEnum,ProductionEnum,VersionEnum> branch0;

}
